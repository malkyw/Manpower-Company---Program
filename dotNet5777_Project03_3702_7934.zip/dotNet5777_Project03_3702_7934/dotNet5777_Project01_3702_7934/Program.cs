﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5777_Project01_3702_7934
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
