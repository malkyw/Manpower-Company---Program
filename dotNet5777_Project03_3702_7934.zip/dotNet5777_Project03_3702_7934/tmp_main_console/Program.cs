﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tmp_main_console
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                BL.IBL bl;
                bl = BL.Factory_BL.GetBL();

                #region add func
                #region check add contract
                try
                {

                    bl.add_contract(new BE.Contract
                    {
                        Contract_number = "0",
                        Employer_id = "123456789",
                        Employee_id = "234567890",
                        Had_interviewed = true,
                        Had_sighed_contract = true,
                        Rate_per_hour_gross = 70,
                        Rate_per_hour_net = 40,
                        Beginning_of_work = new DateTime(9 / 7 / 2013),
                        End_of_work = new DateTime(9 / 7 / 2015),
                    });
                    bl.add_contract(new BE.Contract
                    {
                        Contract_number = "0",
                        Employer_id = "123456789",
                        Employee_id = "234567890",
                        Had_interviewed = true,
                        Had_sighed_contract = false,
                        Rate_per_hour_gross = 60,
                        Rate_per_hour_net = 40,
                        Beginning_of_work = new DateTime(10 / 7 / 2013),
                        End_of_work = new DateTime(10 / 7 / 2016),
                    });

                }


                catch (Exception e)
                { Console.WriteLine(e); }
                #endregion

                var clist = bl.get_Contracts();
                foreach (var item in clist)
                    Console.WriteLine(item);


                #region check add employee 
                try
                {

                    bl.add_employee(new BE.Employee
                    {
                        Id_number = "494949494",
                        First_name = "moshe",
                        Last_name = "levi",
                        Birth_date = new DateTime(26 / 08 / 2015),
                        Phone_number = "0527173794",
                        Address = "hamem gimel 33",
                        Accademic_degree = BE.enumClass.academic_state.student,
                        Army_graduate = false,
                        Experiance = 5,
                        Bank_information = new BE.BankAccount { BankNumber = 123, BankName = "pagi", BankBranchNumber = 85, BranchAddress = "shamgr 16", BranchCity = "jerusalem", AccountNumber = "123456" },
                        Speciality_number = "10000001",
                        Recommemdations = "aaa",
                    });
                    bl.add_employee(new BE.Employee
                    {
                        Id_number = "474949494",
                        First_name = "dan",
                        Last_name = "levitan",
                        Birth_date = new DateTime(26 / 08 / 1993),
                        Phone_number = "0527173794",
                        Address = "hamem gimel 33",
                        Accademic_degree = BE.enumClass.academic_state.student,
                        Army_graduate = false,
                        Experiance = 5,
                        Bank_information = new BE.BankAccount { BankNumber = 123, BankName = "pagi", BankBranchNumber = 85, BranchAddress = "shamgr 16", BranchCity = "jerusalem", AccountNumber = "123456" },
                        Speciality_number = "10000001",
                        Recommemdations = "aaa",
                    });
                }


                catch (Exception e)
                { Console.WriteLine(e); }
                #endregion

                var emplist = bl.get_employees();
                foreach (var item in emplist)
                    Console.WriteLine(item);


                #region check add employer
                try
                {

                    bl.add_employer(new BE.Employer
                    {
                        Id_number = "398756894",
                        IsPrivate = false,
                        First_name = "no",
                        Last_name = "no",
                        CompanyName = "intel",
                        Phone_number = "0527173694",
                        Address = "har hotzvim",
                        OccupationField = BE.enumClass.specializatinFailed.hardwere_engineereing,
                        BusinessCreationDate = new DateTime(12 / 1 / 2000),
                    });
                    bl.add_employer(new BE.Employer
                    {
                        Id_number = "12398789",
                        IsPrivate = false,
                        First_name = "no",
                        Last_name = "no",
                        CompanyName = "intel",
                        Phone_number = "0527173694",
                        Address = "har hotzvim",
                        OccupationField = BE.enumClass.specializatinFailed.hardwere_engineereing,
                        BusinessCreationDate = new DateTime(12 / 1 / 2000),
                    });
                }


                catch (Exception e)
                { Console.WriteLine(e); }
                #endregion

                var elist = bl.get_employers();
                foreach (var item in elist)
                    Console.WriteLine(item);

                #region check add specialaziation
                try
                {

                    bl.add_specialization(new BE.Specialization
                    {
                        Speciality_number = "0",
                        SpecialityField = BE.enumClass.specializatinFailed.information_systems,
                        Speciality_name = "dotnet",
                        MinRatePerHour = 40,
                        MaxRatePerHour = 200,
                    });
                    bl.add_specialization(new BE.Specialization
                    {
                        Speciality_number = "0",
                        SpecialityField = BE.enumClass.specializatinFailed.infuastructure_computers,
                        Speciality_name = "dotnet",
                        MinRatePerHour = 70,
                        MaxRatePerHour = 200,
                    });
                }


                catch (Exception e)
                { Console.WriteLine(e); }
                #endregion

                var slist = bl.get_specializiations();
                foreach (var item in slist)
                    Console.WriteLine(item);

                #endregion

                //#region update func
                //#region check update contract
                //try
                //{

                //    bl.update_Contract(new BE.Contract
                //    {
                //        Contract_number = "10000004",
                //        Employer_id = "123456789",
                //        Employee_id = "234567890",
                //        Had_interviewed = true,
                //        Had_sighed_contract = false,
                //        Rate_per_hour_gross = 70,
                //        Rate_per_hour_net = 40,
                //        Beginning_of_work = new DateTime(9 / 7 / 2013),
                //        End_of_work = new DateTime(9 / 7 / 2015),
                //    });

                //}


                //catch (Exception e)
                //{ Console.WriteLine(e); }
                //#endregion

                //var cuplist = bl.get_Contracts();
                //foreach (var item in cuplist)
                //    Console.WriteLine(item);


                //#region check update employee 
                //try
                //{

                //    bl.update_employee(new BE.Employee
                //    {
                //        Id_number = "494949494",
                //        First_name = "ahron",
                //        Last_name = "levi",
                //        Birth_date = new DateTime(26 / 08 / 2015),
                //        Phone_number = "0527173794",
                //        Address = "hamem gimel 33",
                //        Accademic_degree = BE.enumClass.academic_state.student,
                //        Army_graduate = false,
                //        Experiance = 5,
                //        Bank_information = new BE.BankAccount { BankNumber = 123, BankName = "pagi", BankBranchNumber = 85, BranchAddress = "shamgr 16", BranchCity = "jerusalem", AccountNumber = "123456" },
                //        Speciality_number = "10000001",
                //        Recommemdations = "aaa",
                //    });

                //}


                //catch (Exception e)
                //{ Console.WriteLine(e); }
                //#endregion

                //var empuplist = bl.get_employees();
                //foreach (var item in empuplist)
                //    Console.WriteLine(item);


                //#region check update employer
                //try
                //{

                //    bl.update_employer(new BE.Employer
                //    {
                //        Id_number = "398756894",
                //        IsPrivate = false,
                //        First_name = "no",
                //        Last_name = "no",
                //        CompanyName = "intel",
                //        Phone_number = "0529993694",
                //        Address = "har hotzvim",
                //        OccupationField = BE.enumClass.specializatinFailed.hardwere_engineereing,
                //        BusinessCreationDate = new DateTime(12 / 1 / 2000),
                //    });

                //}


                //catch (Exception e)
                //{ Console.WriteLine(e); }
                //#endregion

                //var euplist = bl.get_employers();
                //foreach (var item in euplist)
                //    Console.WriteLine(item);

                //#region check update specialaziation
                //try
                //{

                //    bl.update_specializiation(new BE.Specialization
                //    {
                //        Speciality_number = "10000004",
                //        SpecialityField = BE.enumClass.specializatinFailed.information_systems,
                //        Speciality_name = "dotnet",
                //        MinRatePerHour = 30,
                //        MaxRatePerHour = 200,
                //    });

                //}


                //catch (Exception e)
                //{ Console.WriteLine(e); }
                //#endregion

                //var sUPlist = bl.get_specializiations();
                //foreach (var item in sUPlist)
                //    Console.WriteLine(item);
                //#endregion

                //#region delete func
                //#region check delete contract
                //try
                //{

                //    bl.delete_contract("10000004");
                //    bl.delete_contract("10000000");
                //}
                //catch (Exception e)
                //{ Console.WriteLine(e); }
                //#endregion

                //var cdlist = bl.get_Contracts();
                //foreach (var item in cdlist)
                //    Console.WriteLine(item);


                //#region check delete employee 
                //try
                //{

                //    bl.delete_employee("494949494");
                //    bl.delete_employee("987680494");

                //}


                //catch (Exception e)
                //{ Console.WriteLine(e); }
                //#endregion

                //var empdlist = bl.get_employees();
                //foreach (var item in empdlist)
                //    Console.WriteLine(item);


                //#region check del employer
                //try
                //{

                //    bl.delete_employer("398756894");
                //    bl.delete_employer("398888894");

                //}


                //catch (Exception e)
                //{ Console.WriteLine(e); }
                //#endregion

                //var edlist = bl.get_employers();
                //foreach (var item in edlist)
                //    Console.WriteLine(item);

                //#region check del specialaziation
                //try
                //{

                //    bl.delete_specializiation("10000004");
                //    bl.delete_specializiation("10000007");
                //}


                //catch (Exception e)
                //{ Console.WriteLine(e); }
                //#endregion

                //var sdlist = bl.get_specializiations();
                //foreach (var item in sdlist)
                //    Console.WriteLine(item);
                //#endregion




                //int num = bl.get_num_contrct(ty => ty.Employer_id == "123456789");
                //Console.WriteLine(Convert.ToString(num));

                //string str = bl.profit_per_year();
                //Console.WriteLine(str);

                //var v = bl.spcialization_contracts(false);
                //foreach (var item in v)
                //{
                //    Console.WriteLine("'{0}':", item.Key);
                //    foreach (var w in item)
                //        Console.WriteLine(w);
                //}
                ////Console.WriteLine();

                //var a = bl.city_contracts(true);
                //foreach (var item in a)
                //    Console.WriteLine(item);

                //var b = bl.spcialization_employees(true);
                //foreach (var item in b)
                //    Console.WriteLine(item);

                //var c = bl.degree_employees(false);
                //foreach (var item in c)
                //    Console.WriteLine(item);

                //var d = bl.age_employees(false);
                //foreach (var item in d)
                //    Console.WriteLine(item);

                //var ae = bl.privet_employers(false);
                //foreach (var item in ae)
                //    Console.WriteLine(item);

                //var f = bl.spcialization_employees();
                //foreach (var item in f)
                //    Console.WriteLine(item);

                //var g = bl.employees_to_employer("123456789");
            
            }

            catch (Exception e) { Console.WriteLine(e); }
        }
    }
}
