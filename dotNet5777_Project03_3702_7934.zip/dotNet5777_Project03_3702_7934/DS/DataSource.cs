﻿using System;
using System.Collections.Generic;
using BE;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DS
{
    public class DataSource
    {
        public static List<BE.Specialization> specializations_list= new List<BE.Specialization>();
        public static List<BE.Employee> employees_list= new List<BE.Employee>();
        public static List<BE.Employer> employers_list= new List<BE.Employer>();
        public static List<BE.Contract> contract_list= new List<BE.Contract>();
        public  static List<BE.BankAccount> bank_list = new List<BE.BankAccount>();
        public static List<string> function_name_list;
    }
}