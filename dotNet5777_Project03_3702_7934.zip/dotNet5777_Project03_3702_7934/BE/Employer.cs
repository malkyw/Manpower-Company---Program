﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Employer
    {
        public string Id_number { get; set; }
        public bool IsPrivate { get; set; }//if the oner is a private man or a businss
        public string First_name { get; set; }
        public string Last_name { get; set; }
        public string CompanyName { get; set; }
        public string Phone_number { get; set; }
        public string Address { get; set; }
        public enumClass.specializatinFailed OccupationField { get; set; }
        public DateTime BusinessCreationDate { get; set; }
        private string imageSource;
        public string ImageSource
        {
            get { return imageSource; }
            set { imageSource = value; }
        }

        public Employer()
        {
            imageSource = (@"Empty Image");

        }
        public override string ToString()
        {
            return this.ToStringProperty();
        }
    }
}
