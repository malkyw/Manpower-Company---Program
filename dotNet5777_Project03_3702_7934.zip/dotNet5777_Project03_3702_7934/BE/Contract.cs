﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Contract
    {
        public string Contract_number { get; set; }
        public string Employer_id { get; set; }
        public string Employee_id { get; set; }
        public bool Had_interviewed { get; set; }
        public bool Had_sighed_contract { get; set; }
        public double Rate_per_hour_gross { get; set; }
        public double Rate_per_hour_net { get; set; }
        public DateTime Beginning_of_work { get; set; }
        public DateTime End_of_work { get; set; }
        public float? Num_hours_of_work { get; set; }//per month
        public override string ToString()
        {
            return this.ToStringProperty();
        }
    }
}
