﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BankAccount
    {
        public int BankNumber { get; set; }
        public string BankName { get; set; }
        public int BankBranchNumber { get; set; }
        public string BranchAddress { get; set; }
        public string BranchCity { get; set; }
        public int AccountNumber { get; set; }
        public override string ToString()
        {
            return string.Format("\nBank: {0} bank\nbank number: {1}\nbranch number: {2}\naddress: {3} {4}\naccount number: {5}",
                BankName, BankNumber, BankBranchNumber, BranchAddress, BranchCity, AccountNumber);
        }
    }
}
