﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class enumClass
    {
        public enum specializatinFailed {software_engineereing ,hardwere_engineereing, QA, infuastructure_computers, information_systems }//תחום הממומחיות
        public enum academic_state { diploma,BA,MA,PHD,student }//

    }
}
