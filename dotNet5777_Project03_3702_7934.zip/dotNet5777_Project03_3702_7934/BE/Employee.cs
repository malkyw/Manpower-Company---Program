﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Employee
    {
        public string Id_number { get; set; }
        public string First_name { get; set; }
        public string Last_name { get; set; }
        public DateTime Birth_date { get; set;}
        public string Phone_number { get; set;}
        public string Address { get; set; }
        public enumClass.academic_state Accademic_degree { get; set; }
        public bool Army_graduate { get; set;}
        public int Experiance { get; set; }
        public string Speciality_number { get; set; }
        public BankAccount Bank_information {get; set;}
        public string Recommemdations { get; set; }//המלצות
        private string imageSource;
        public string ImageSource
        {
            get { return imageSource; }
            set { imageSource = value; }
        }

        public Employee()
        {
            imageSource = (@"Empty Image");

        }
        public override string ToString()
        {
            return this.ToStringProperty();
        }
    }
}
