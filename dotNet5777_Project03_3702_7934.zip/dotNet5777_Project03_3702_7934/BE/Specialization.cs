﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Specialization
    {
        public string Speciality_number { get; set; }
        public enumClass.specializatinFailed SpecialityField { get; set; }// the field he specializes in תחום ההתמחות
        public string Speciality_name { get; set; }//speciality name שם המומוחיות
        public double MinRatePerHour { get; set; }
        public double MaxRatePerHour { get; set; }
        public override string ToString ()//to string of class
        {
            return this.ToStringProperty();
        }
    }
}
