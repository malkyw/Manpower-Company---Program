﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for AddEmployerWindow.xaml
    /// </summary>
    public partial class AddUpdateEmployerWindow : Window
    {
        BL.IBL bl;
        BE.Employer emp;
        BE.Employer tmp;

        public AddUpdateEmployerWindow()//defult ctor
        {
            InitializeComponent();
        }

        public AddUpdateEmployerWindow(string sender)//parameter ctor
        {
            InitializeComponent();
            emp = new BE.Employer();
            this.DataContext = emp;
            bl = BL.Factory_BL.GetBL();

            this.id_numberComboBox.ItemsSource = bl.get_employers();
            this.id_numberComboBox.SelectedValuePath = "Id_number";
            this.id_numberComboBox.DisplayMemberPath= "Id_number";

            if (sender == "add")
            {
                this.Title = "add employer";
                this.Add_update_label.Content = "add new employer";
                this.Add_update_Button.Content = "add";
                this.id_numberComboBox.Visibility = System.Windows.Visibility.Collapsed;
                this.occupationFieldComboBox.ItemsSource = Enum.GetValues(typeof(BE.enumClass.specializatinFailed));
               
            }
            if (sender == "update")
            {
                if (this.id_numberComboBox.Items.Count == 0)
                {
                    MessageBox.Show("There are no employers to update.");
                    this.Close();
                }
                this.Title = "update employer";
                this.Add_update_label.Content = "update employer";
                this.Add_update_Button.Content = "update";
                this.id_numberTextBox.IsEnabled = false;
                this.id_numberComboBox.Visibility = System.Windows.Visibility.Visible;
                this.addressTextBox.IsEnabled = false;
                this.businessCreationDateDatePicker.IsEnabled = false;
                this.companyNameTextBox.IsEnabled = false;
                this.first_nameTextBox.IsEnabled = false;
                this.isPrivateCheckBox.IsEnabled = false;
                this.last_nameTextBox.IsEnabled = false;
                this.occupationFieldComboBox.IsEnabled = false;
                this.phone_numberTextBox.IsEnabled = false;
                this.occupationFieldComboBox.ItemsSource = Enum.GetValues(typeof(BE.enumClass.specializatinFailed));
                this.employerImage.IsEnabled = true;

            }
        }

        private void Add_update_Button_Click(object sender, RoutedEventArgs e)//add-update
        {
            try
            {
                if ((string)(sender as Button).Content == "add")
                {
                    if (this.id_numberTextBox.BorderBrush == Brushes.Red || this.first_nameTextBox.BorderBrush == Brushes.Red || this.last_nameTextBox.BorderBrush == Brushes.Red || this.phone_numberTextBox.BorderBrush == Brushes.Red)
                        return;
                    
                    bl.add_employer(emp);
                    string name = "";
                    if (this.isPrivateCheckBox.IsChecked == true)
                        name = this.first_nameTextBox.Text +" "+ this.last_nameTextBox.Text;
                    else
                        name = this.companyNameTextBox.Text;
                    MessageBox.Show(string.Format("the employer {0} was added.",name));
                    emp = new BE.Employer();
                    this.DataContext = emp;
                    this.id_numberTextBox.BorderBrush = Brushes.LightBlue;
                    this.first_nameTextBox.BorderBrush = Brushes.LightBlue;
                    this.last_nameTextBox.BorderBrush = Brushes.LightBlue;
                    this.phone_numberTextBox.BorderBrush = Brushes.LightBlue;
                }

                else//update
                {
                    if (this.first_nameTextBox.BorderBrush == Brushes.Red || this.last_nameTextBox.BorderBrush == Brushes.Red || this.phone_numberTextBox.BorderBrush == Brushes.Red)
                        return;
                    bl.update_employer(tmp);
                    string name = "";
                    if (this.isPrivateCheckBox.IsChecked == true)
                        name = this.first_nameTextBox.Text + " " + this.last_nameTextBox.Text;
                    else
                        name = this.companyNameTextBox.Text;
                    MessageBox.Show(string.Format("the employer {0} was updated.", name)); this.id_numberTextBox.BorderBrush = Brushes.LightBlue;
                    this.first_nameTextBox.BorderBrush = Brushes.LightBlue;
                    this.last_nameTextBox.BorderBrush = Brushes.LightBlue;
                    this.phone_numberTextBox.BorderBrush = Brushes.LightBlue;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
          
            }

        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)//close
        {
            this.Close();
        }

        private void check_TextChanged(object sender, TextChangedEventArgs e)//check text
        {
            
            string text = (sender as TextBox).Text;
            if (check_string(text) == false)
                (sender as TextBox).BorderBrush = Brushes.Red;
            else
                (sender as TextBox).BorderBrush = Brushes.LightBlue;

        }

        private bool check_string(string text)//check if is string
        {
            for (int i = 0; i < text.Length; i++)
                if (text[i] > 'a' && text[i] < 'z')
                    return true;
            return false;
        }

        private bool check_int(string text)//check if is int
        {
            for (int i = 0; i < text.Length; i++)
                if (text[i] > 'a' && text[i] < 'z')
                    return false;
            return true;
        }

        private void check_id(object sender, TextChangedEventArgs e)//check the id number
       {

            string text = (sender as TextBox).Text;
            if (text.Length != 9 || !check_int(text))
            {
                (sender as TextBox).BorderBrush = Brushes.Red;
            }
            if (text.Length == 9 && check_int(text))
            {
                (sender as TextBox).BorderBrush = Brushes.LightBlue;
            }
        }

        private void employer_info(object sender, SelectionChangedEventArgs e)//return the information of the given employer id number
        {
        
            object result = this.id_numberComboBox.SelectedValue;

            emp = bl.get_employer(result as string);
            if (emp != null)
            {
                tmp = new BE.Employer();
                #region tmp=emp
                tmp.Address = emp.Address;
                tmp.BusinessCreationDate = emp.BusinessCreationDate;
                tmp.CompanyName = emp.CompanyName;
                tmp.First_name = emp.First_name;
                tmp.Id_number = emp.Id_number;
                tmp.IsPrivate = emp.IsPrivate;
                tmp.Last_name = emp.Last_name;
                tmp.OccupationField = emp.OccupationField;
                tmp.Phone_number = emp.Phone_number;
                tmp.ImageSource = emp.ImageSource;
                #endregion
                this.DataContext = tmp;
                this.addressTextBox.IsEnabled = true;
                this.businessCreationDateDatePicker.IsEnabled = true;
                this.isPrivateCheckBox.IsEnabled = true;
                this.occupationFieldComboBox.IsEnabled = true;
                this.phone_numberTextBox.IsEnabled = true;
                this.employerImage.IsEnabled = true;
                if(isPrivateCheckBox.IsChecked==true)
                {
                    this.companyNameTextBox.IsEnabled = false;
                    this.company_name.Foreground = Brushes.Gray;
                    this.first_nameTextBox.IsEnabled = true;
                    this.first_name.Foreground = Brushes.Black;
                    this.last_nameTextBox.IsEnabled = true;
                    this.last_name.Foreground = Brushes.Black;
                }

                if (isPrivateCheckBox.IsChecked == false)
                {
                    this.companyNameTextBox.IsEnabled = true;
                    this.company_name.Foreground = Brushes.Black;
                    this.first_nameTextBox.IsEnabled = false;
                    this.first_name.Foreground = Brushes.Gray;
                    this.last_nameTextBox.IsEnabled = false;
                    this.last_name.Foreground = Brushes.Gray;
                }
            }
            else
                MessageBox.Show("an employer with this number does not exist.");

        }
      
        private void phone_numberTextBox_TextChanged(object sender, TextChangedEventArgs e)//check phone number
        {
            string text = (sender as TextBox).Text;
            if (text.Length != 10 || !check_int(text))
            {
                (sender as TextBox).BorderBrush = Brushes.Red;
            }
            if (text.Length == 10 && check_int(text))
            {
                (sender as TextBox).BorderBrush = Brushes.LightBlue;
            }
        }

        private void isPrivateCheckBox_Unchecked(object sender, RoutedEventArgs e)//check if private or company
        {
            this.companyNameTextBox.IsEnabled = true;
            this.company_name.Foreground = Brushes.Black;
            this.first_name.Foreground = Brushes.Gray;
            this.first_nameTextBox.Text = null;
            this.first_nameTextBox.BorderBrush = Brushes.Gray;
            this.last_name.Foreground = Brushes.Gray;
            this.last_nameTextBox.Text = null;
            this.last_nameTextBox.BorderBrush = Brushes.Gray;
            this.first_nameTextBox.IsEnabled = false;
            this.last_nameTextBox.IsEnabled = false;
        }

        private void isPrivateCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            this.companyNameTextBox.IsEnabled = false;
            this.companyNameTextBox.Text = null;
            this.companyNameTextBox.BorderBrush = Brushes.Gray;
            this.company_name.Foreground = Brushes.Gray;
            this.first_name.Foreground = Brushes.Black;
            this.last_name.Foreground = Brushes.Black;
            this.first_nameTextBox.IsEnabled = true;
            this.last_nameTextBox.IsEnabled = true;
        }

     
        private void changeImageButton_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog f = new Microsoft.Win32.OpenFileDialog();
            f.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif";
            if (f.ShowDialog() == true)
            {
                this.employerImage.Source = new BitmapImage(new Uri(f.FileName));
            }
        }
    }
}