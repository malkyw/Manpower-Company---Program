﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       public BL.IBL bl = BL.Factory_BL.GetBL();
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void SpecializationButton_Click(object sender, RoutedEventArgs e)
        {
            Window specialWindow = new SpecializiationWindow();
            specialWindow.ShowDialog();
        }

        private void ContractButton_Click(object sender, RoutedEventArgs e)
        {
            Window contWindow = new ContractWindow();
            contWindow.ShowDialog();
            
        }

        private void EmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            Window employeeWindow = new EmployeeWindow();
            employeeWindow.ShowDialog();
        }

        private void EmployerButton_Click(object sender, RoutedEventArgs e)
        {
            Window employerWindow = new EmployerWindow();
            employerWindow.ShowDialog();
            
        }

        private void MoreOptionsButton_Click(object sender, RoutedEventArgs e)
        {
            Window more_window = new more_options_window();
            more_window.ShowDialog();

        }
    }
}
