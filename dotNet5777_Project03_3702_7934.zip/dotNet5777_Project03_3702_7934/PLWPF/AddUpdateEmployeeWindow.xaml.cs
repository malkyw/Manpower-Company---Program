﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for AddUpdateEmployeeWindow.xaml
    /// </summary>
    public partial class AddUpdateEmployeeWindow : Window
    {
        BL.IBL bl;
        BE.Employee emp;
        BE.Employee tmp;
        BE.BankAccount bank;
        BE.BankAccount tmp_bank;

        public AddUpdateEmployeeWindow()//defult ctor
        {
            InitializeComponent();
        }

        public AddUpdateEmployeeWindow(string sender)//parameter ctor
        {
            InitializeComponent();
            emp = new BE.Employee();
            bank = new BE.BankAccount();
            this.DataContext = emp;
            this.grid2.DataContext = bank;
          
            bl = BL.Factory_BL.GetBL();

            this.bankNameComboBox.ItemsSource = bl.get_bank_names();

            this.id_numberComboBox.ItemsSource = bl.get_employees();
            this.id_numberComboBox.DisplayMemberPath = "Id_number";
            this.id_numberComboBox.SelectedValuePath = "Id_number";

            this.speciality_numberComboBox.ItemsSource = bl.get_specializiations();
            this.speciality_numberComboBox.DisplayMemberPath = "Speciality_number";
            this.speciality_numberComboBox.SelectedValuePath = "Speciality_number";

            this.accademic_degreeComboBox.ItemsSource = Enum.GetValues(typeof(BE.enumClass.academic_state));

            this.branchAddressTextBox.IsEnabled = false;
            this.bankNumberTextBox.IsEnabled = false;
            this.branchCityTextBox.IsEnabled = false;

            if (sender == "add")
            {
                this.Title = "add employee";
                this.Add_update_label.Content = "add new employee";
                this.Add_update_Button.Content = "add";
                this.id_numberComboBox.Visibility = System.Windows.Visibility.Collapsed;
            }
            if(sender=="update")
            {
                //if id number ComboBox is empty then message and close the window
                if (this.id_numberComboBox.Items.Count == 0)
                {
                    MessageBox.Show("There are no employees to update.");
                    this.Close();
                }
                this.Title = "update employee";
                this.Add_update_label.Content = "update new employee";
                this.Add_update_Button.Content = "update";
                this.id_numberComboBox.Visibility = System.Windows.Visibility.Visible;
                this.id_numberTextBox.Visibility = System.Windows.Visibility.Collapsed;            
                this.accademic_degreeComboBox.IsEnabled = false;
                this.addressTextBox.IsEnabled = false;
                this.army_graduateCheckBox.IsEnabled = false;
                this.birth_dateDatePicker.IsEnabled = false;
                this.first_nameTextBox.IsEnabled = false;
                this.last_nameTextBox.IsEnabled = false;
                this.phone_numberTextBox.IsEnabled = false;
                this.recommemdationsTextBox.IsEnabled = false;
                this.speciality_numberComboBox.IsEnabled = false;
                this.accountNumberTextBox.IsEnabled = false;
                this.bankBranchNumberTextBox.IsEnabled = false;
                this.bankNameComboBox.IsEnabled = false;
                this.bankNumberTextBox.IsEnabled = false;
                this.branchAddressTextBox.IsEnabled = false;
                this.employeeImage.IsEnabled = false;
                this.bankBranchNumberTextBox.SelectedItem = "bankBranchNumber";
            }

        }

        private void check_id(object sender, TextChangedEventArgs e)//check the id number
        {

            string text = (sender as TextBox).Text;
            if (text.Length != 9 || !check_int(text))
            {
                (sender as TextBox).BorderBrush = Brushes.Red;
            }
            if (text.Length == 9 && check_int(text))
            {
                (sender as TextBox).BorderBrush = Brushes.LightBlue;
            }
        } 

        private void check_text(object sender, TextChangedEventArgs e)//check the text
        {
            string text = (sender as TextBox).Text;
            if (check_string(text) == false)
                (sender as TextBox).BorderBrush = Brushes.Red;
            else
                (sender as TextBox).BorderBrush = Brushes.LightBlue;
        }

        private bool check_int(string text)//check if is int
        {
            for (int i = 0; i < text.Length; i++)
                if (text[i] > 'a' && text[i] < 'z')
                    return false;
            return true;
        }

        private void phone_numberTextBox_TextChanged(object sender, TextChangedEventArgs e)//check phone number is 10 digits
        {
            string text = (sender as TextBox).Text;
            if (text.Length != 10 || !check_int(text))
            {
                (sender as TextBox).BorderBrush = Brushes.Red;
            }
            if (text.Length == 10 && check_int(text))
            {
                (sender as TextBox).BorderBrush = Brushes.LightBlue;
            }
        }

        private bool check_string(string text)//check if is string
        {
            for (int i = 0; i < text.Length; i++)
                if (text[i] > 'a' && text[i] < 'z')
                    return true;
            return false;
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)//close the window
        {
            this.Close();
        }

        private void Add_update_Button_Click(object sender, RoutedEventArgs e)//add-apdate
        { 
        try
            {
               
                if ((string)(sender as Button).Content == "add")
                {
                    if (this.id_numberTextBox.BorderBrush == Brushes.Red || this.first_nameTextBox.BorderBrush == Brushes.Red || this.experianceTextBox.BorderBrush == Brushes.Red || this.last_nameTextBox.BorderBrush == Brushes.Red || this.phone_numberTextBox.BorderBrush == Brushes.Red)
                        return;
                    bank.BankNumber = Convert.ToInt32(this.bankNumberTextBox.Text);
                    bank.BranchAddress = this.branchAddressTextBox.Text;
                    bank.BranchCity = this.branchCityTextBox.Text;
                    emp.Bank_information = bank;
                    bl.add_employee(emp);
             
                    MessageBox.Show(string.Format("the employee {0} was added.",emp.Id_number));

                    emp = new BE.Employee();
                    this.DataContext = emp;
                    bank = new BE.BankAccount();

                    this.id_numberTextBox.BorderBrush = Brushes.LightBlue;
                    this.first_nameTextBox.BorderBrush = Brushes.LightBlue;
                    this.experianceTextBox.BorderBrush = Brushes.LightBlue;
                    this.last_nameTextBox.BorderBrush = Brushes.LightBlue;
                    this.phone_numberTextBox.BorderBrush = Brushes.LightBlue;
                    this.branchCityTextBox.BorderBrush = Brushes.LightBlue;
                    this.accountNumberTextBox.Text = "";
                    this.bankBranchNumberTextBox.SelectedValue = "";
                    this.bankNameComboBox.SelectedValue = "";
                    this.branchAddressTextBox.Text = "";
                    this.branchCityTextBox.Text = "";
                    this.bankNumberTextBox.Text = "";
                    this.bankBranchNumberTextBox.BorderBrush = Brushes.LightBlue;
                }

                else//update
                {
                    if(this.first_nameTextBox.BorderBrush == Brushes.Red || this.last_nameTextBox.BorderBrush == Brushes.Red || this.phone_numberTextBox.BorderBrush == Brushes.Red)
                        return;
                    tmp.Bank_information = tmp_bank;
                    bl.update_employee(tmp);
                    MessageBox.Show(string.Format("the employee {0} was updated.", emp.Id_number));
                    this.first_nameTextBox.BorderBrush = Brushes.LightBlue;
                    this.experianceTextBox.BorderBrush = Brushes.LightBlue;
                    this.last_nameTextBox.BorderBrush = Brushes.LightBlue;
                    this.phone_numberTextBox.BorderBrush = Brushes.LightBlue;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
}

        private void employee_info(object sender, SelectionChangedEventArgs e)//returns the information of the given employee id number
        {
            object result = this.id_numberComboBox.SelectedValue;
            emp = bl.get_employee(result as string);
            if (emp != null)
            {
                tmp = new BE.Employee();
                tmp_bank = new BE.BankAccount();
                //for deep copying
                #region tmp=emp
                tmp.Address = emp.Address;
                tmp.Accademic_degree = emp.Accademic_degree;
                tmp.Army_graduate = emp.Army_graduate;
                tmp.First_name = emp.First_name;
                tmp.Id_number = emp.Id_number;
                tmp.Birth_date = emp.Birth_date;
                tmp.Last_name = emp.Last_name;
                tmp.Experiance = emp.Experiance;
                tmp.Phone_number = emp.Phone_number;
                tmp.Recommemdations = emp.Recommemdations;
                tmp.Speciality_number = emp.Speciality_number;
                tmp.ImageSource = emp.ImageSource;
                #endregion
                this.DataContext = tmp;
                bank = emp.Bank_information;
                #region tmp bank=bank
                tmp_bank.AccountNumber = bank.AccountNumber;
                tmp_bank.BankBranchNumber = bank.BankBranchNumber;
                tmp_bank.BankName = bank.BankName;
                tmp_bank.BankNumber = bank.BankNumber;
                tmp_bank.BranchAddress = bank.BranchAddress;
                tmp_bank.BranchCity = bank.BranchCity;
                #endregion
                this.grid2.DataContext = tmp_bank;
                this.id_numberTextBox.IsEnabled = false;
                this.id_numberTextBox.Foreground = Brushes.Gray;
                this.idNumberLebel.Background = Brushes.Gray;
                this.accademic_degreeComboBox.IsEnabled = true;
                this.addressTextBox.IsEnabled = true;
                this.army_graduateCheckBox.IsEnabled = true;
                this.birth_dateDatePicker.IsEnabled = true;
                this.experianceTextBox.IsEnabled = true;
                this.first_nameTextBox.IsEnabled = true;
                this.last_nameTextBox.IsEnabled = true;
                this.phone_numberTextBox.IsEnabled = true;
                this.recommemdationsTextBox.IsEnabled = true;
                this.speciality_numberComboBox.IsEnabled = true;
                this.accountNumberTextBox.IsEnabled = true;
                this.bankBranchNumberTextBox.IsEnabled = true;
                this.bankNameComboBox.IsEnabled = true;
                this.bankNumberTextBox.IsEnabled = true;
                this.branchAddressTextBox.IsEnabled = true;
                this.branchCityTextBox.IsEnabled = true;
                this.employeeImage.IsEnabled = true;
            }
        }

        private void changeImageButton_Click(object sender, RoutedEventArgs e)//change the image
        {
            Microsoft.Win32.OpenFileDialog f = new Microsoft.Win32.OpenFileDialog();
            f.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif";
            if (f.ShowDialog() == true)
            {
                this.employeeImage.Source = new BitmapImage(new Uri(f.FileName));
            }
        }

        private void experianceTextBox_TextChanged(object sender, TextChangedEventArgs e) //check if experiance is positive and not more than his age
        {

            if (Convert.ToInt32((sender as TextBox).Text)<0|| Convert.ToInt32((sender as TextBox).Text)>(DateTime.Now.Date.Year-(Convert.ToDateTime(this.birth_dateDatePicker.Text).Year)))
            {
                (sender as TextBox).BorderBrush = Brushes.Red;

            }//correct
            else
            {
                (sender as TextBox).BorderBrush = Brushes.LightBlue;

            }
        }

        private void bankNameComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            object result = this.bankNameComboBox.SelectedValue;
            this.bankBranchNumberTextBox.ItemsSource = bl.get_bank_branches(result as string);
            var bank = bl.get_banks(result as string);
            BE.BankAccount my_bank = bank.ToList().FirstOrDefault();
            this.bankNumberTextBox.Text = Convert.ToString(my_bank.BankNumber);
        }

        private void bankBranchNumberTextBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            object bank_result= this.bankNameComboBox.SelectedValue;
            object branch_result = this.bankBranchNumberTextBox.SelectedValue;
            if (branch_result == null)
                return;
            var bank = bl.get_branch(bank_result as string, Convert.ToInt32(branch_result));
            BE.BankAccount my_bank= bank.ToList().FirstOrDefault();
            this.branchAddressTextBox.Text = my_bank.BranchAddress;
            this.branchCityTextBox.Text = my_bank.BranchCity;

        }
    }
}
