﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for DeleteWindow.xaml
    /// </summary>
    public partial class DeleteWindow : Window
    {
        BL.IBL bl = BL.Factory_BL.GetBL();
        public DeleteWindow()
        {
            InitializeComponent();
        }

        public DeleteWindow(string sender)
        {

            InitializeComponent();

            if (sender == "contract")
            {
                this.label.Content = "enter contract number to delete";
                this.label.Name = "contract";
                this.comboBox.ItemsSource = bl.get_Contracts();
                this.comboBox.DisplayMemberPath = "Contract_number";
                this.comboBox.SelectedValuePath = "Contract_number";
            }
            if (sender == "specilization")
            {
                this.label.Content = "enter specilization number to delete";
                this.label.Name = "specilization";
                this.label.FontSize = 16;
                this.comboBox.ItemsSource = bl.get_specializiations();
                this.comboBox.DisplayMemberPath = "Speciality_number";
                this.comboBox.SelectedValuePath = "Speciality_number";
            }
            if (sender == "employee")
            {
                this.label.Content = "enter employee id to delete";
                this.label.Name = "employee";
                this.comboBox.ItemsSource = bl.get_employees();
                this.comboBox.DisplayMemberPath = "Id_number";
                this.comboBox.SelectedValuePath = "Id_number";
            }
            if (sender == "employer")
            {
                this.label.Content = "enter employer id to delete";
                this.label.Name = "employer";
                this.comboBox.ItemsSource = bl.get_employers();
                this.comboBox.DisplayMemberPath = "Id_number";
                this.comboBox.SelectedValuePath = "Id_number";
            }
            //if the items list is empty then message and close the window
            if (this.comboBox.Items.Count == 0)
            {
                MessageBox.Show(string.Format("no more {0} to delete.", this.label.Name));
                this.Close();
            }

        }
        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }


        private string getSelection()
        {
            object result = this.comboBox.SelectedValue;
            if (result == null)
                throw new Exception("must select first");
            return (string)result;
        }

        private void deletebBotton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (this.label.Name == "employer")//sender=employer
                {
                    bl.delete_employer(getSelection());
                    MessageBox.Show(string.Format("the employer {0} was deleted.", getSelection()));
                    this.comboBox.ItemsSource = bl.get_employers();
                }

                if (this.label.Name == "employee")//sender = employee
                {
                    bl.delete_employee(getSelection());
                    MessageBox.Show(string.Format("the employee {0} was deleted.", getSelection()));
                    this.comboBox.ItemsSource = bl.get_employees();

                }
                if (this.label.Name== "specilization")//sender = specialization
                {
                    bl.delete_specializiation(getSelection());
                    MessageBox.Show(string.Format("the specializiation {0} was deleted.", getSelection()));
                    this.comboBox.ItemsSource = bl.get_specializiations();

                }
                if (this.label.Name == "contract")//sender=contract
                {
                    bl.delete_contract(getSelection());
                    MessageBox.Show(string.Format("the contract {0} was deleted.", getSelection()));
                    this.comboBox.ItemsSource = bl.get_Contracts();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("{0}", ex.Message));

            }
            if (this.comboBox.Items.Count == 0)//if all items are deleted
            {
                MessageBox.Show(string.Format("there are no {0}s to delete.", this.label.Name));
                this.Close();
            }
        }
    }
}
