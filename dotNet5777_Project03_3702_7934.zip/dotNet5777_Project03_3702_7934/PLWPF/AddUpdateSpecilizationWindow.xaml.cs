﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for AddSpecilizationWindow.xaml
    /// </summary>
    public partial class AddUpdateSpecilizationWindow : Window
    {
        BL.IBL bl;
        BE.Specialization spc;
        BE.Specialization tmp;
        public AddUpdateSpecilizationWindow()//defult ctor
        {
            InitializeComponent();

        }

        public AddUpdateSpecilizationWindow(string sender)//parameter ctor
        {

            InitializeComponent();
            spc = new BE.Specialization();
            this.DataContext = spc;
            this.max_num_up_down.Value = (float?)(spc.MaxRatePerHour);
            this.min_num_up_down.Value = (float?)spc.MinRatePerHour;
            bl = BL.Factory_BL.GetBL();
            this.speciality_numberComboBox.ItemsSource = bl.get_specializiations();
            this.speciality_numberComboBox.DisplayMemberPath = "Speciality_number";
            this.speciality_numberComboBox.SelectedValuePath = "Speciality_number";
            if (sender == "add")
            {
                this.Title = "add Specilization";
                this.AddUpdatelabel.Content = "add new Specilization";
                this.AddButton.Content = "add";
                this.speciality_numberComboBox.IsEnabled = false;
                this.speciality_numberLabel.Foreground = Brushes.Gray;
                this.specialityFieldComboBox.ItemsSource = Enum.GetValues(typeof(BE.enumClass.specializatinFailed));
            }
            if (sender == "update")
            {
                if (this.speciality_numberComboBox.Items.Count == 0)
                {
                    MessageBox.Show("There are no specilizations to update.");
                    this.Close();
                }
                this.Title = "update Specilization";
                this.AddUpdatelabel.Content = "update Specilization";
                this.AddButton.Content = "update";
                this.speciality_numberComboBox.IsEnabled = true;
                this.speciality_numberLabel.Foreground = Brushes.Black;
                this.specialityFieldComboBox.ItemsSource = Enum.GetValues(typeof(BE.enumClass.specializatinFailed));
                this.speciality_nameTextBox.IsEnabled = false;
                this.specialityFieldComboBox.IsEnabled = false;
                this.min_num_up_down.IsEnabled = false;
                this.max_num_up_down.IsEnabled = false;
            }
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)//close
        {
            this.Close();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)//add-update
        {
            try
            {
                if (this.max_num_up_down.Value < this.min_num_up_down.Value)
                    throw new Exception("minimum value must be less than maximum value");
                if ((string)(sender as Button).Content == "add")
                {
                    spc.MinRatePerHour = (double)this.min_num_up_down.Value;
                    spc.MaxRatePerHour = (double)this.max_num_up_down.Value;

                    bl.add_specialization(spc);
                    spc = new BE.Specialization();
                    this.DataContext = spc;
                    MessageBox.Show(string.Format("the specialization {0} was added.", spc.Speciality_name));
                }

                else//update
                {
                    tmp.MinRatePerHour = (double)this.min_num_up_down.Value;
                    tmp.MaxRatePerHour = (double)this.max_num_up_down.Value;
                    bl.update_specializiation(tmp);
                    MessageBox.Show(string.Format("the specialization {0} was updated.", spc.Speciality_name));

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void speciality_numberComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)//return the information of the given specialization number
        {
            object result = this.speciality_numberComboBox.SelectedValue;
           

            spc = bl.get_specialization(result as string);
            if (spc != null)
            {
                tmp = new BE.Specialization();
                #region tmp=spc
                tmp.MaxRatePerHour = spc.MaxRatePerHour;
                tmp.MinRatePerHour = spc.MinRatePerHour;
                tmp.SpecialityField = spc.SpecialityField;
                tmp.Speciality_name = spc.Speciality_name;
                tmp.Speciality_number = spc.Speciality_number;
                #endregion
                this.DataContext = tmp;
                this.max_num_up_down.Value = (float?)tmp.MaxRatePerHour;
                this.min_num_up_down.Value = (float?)tmp.MinRatePerHour;

                this.speciality_numberComboBox.IsEnabled = false;
                this.speciality_numberLabel.Foreground = Brushes.Gray;
                this.speciality_nameTextBox.IsEnabled = true;
                this.specialityFieldComboBox.IsEnabled = true;
                this.min_num_up_down.IsEnabled = true;
                this.max_num_up_down.IsEnabled = true;
            }
            else
                MessageBox.Show("a specialization with this number does not exists.");
        }
    }
}
