﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for allFunctions.xaml
    /// </summary>
    public partial class allFunctions : Window
    {
        BL.IBL bl;

        public allFunctions()//ctor
        {
            bl = BL.Factory_BL.GetBL();
            InitializeComponent();
        }

        private string GetSelectedCoursetId()
        {
            object result = this.function_comboBox.Text;

            if (result == null)
                throw new Exception("must select Course First");
            return (string)result;
        }

        private void Do_button_Click(object sender, RoutedEventArgs e)
        {
            string result = GetSelectedCoursetId();
            if (result == null)
                MessageBox.Show("must select a function.");
            else
            {
                if (result as string == "get employee by army state")
                {
                    grouping_employees_by_degree uc = new grouping_employees_by_degree();
                    if (this.sort_checkBox.IsChecked == true)
                        uc.Source = bl.Army_graduate(true);
                    else
                        uc.Source = bl.Army_graduate();
                    this.page.Content = uc;
                }

                if (result as string == "get private employer")
                {
                    grouping_employees_by_degree uc = new grouping_employees_by_degree();
                    if (this.sort_checkBox.IsChecked == true)
                        uc.Source = bl.privet_employers(true);
                    else
                        uc.Source = bl.privet_employers();
                    this.page.Content = uc;
                }
                if ((string)result == "get contracts by city")
                {
                    grouping_employees_by_degree uc = new grouping_employees_by_degree();
                    if (this.sort_checkBox.IsChecked == true)
                        uc.Source = bl.city_contracts(true);
                    else
                        uc.Source = bl.city_contracts();
                    this.page.Content = uc;
                }

                if (result as string == "get contracts by spcialzation")
                {
                    grouping_employees_by_degree uc = new grouping_employees_by_degree();
                    if (this.sort_checkBox.IsChecked == true)
                        uc.Source = bl.spcialization_contracts(true);
                    else
                        uc.Source = bl.spcialization_contracts();
                    this.page.Content = uc;
                }
                if (result as string == "get employee by spicialization")
                {
                    grouping_employees_by_degree uc = new grouping_employees_by_degree();
                    if (this.sort_checkBox.IsChecked == true)
                        uc.Source = bl.spcialization_employees(true);
                    else
                        uc.Source = bl.spcialization_employees();
                    this.page.Content = uc;
                }
                if (result as string == "get employee by degree")
                {
                    grouping_employees_by_degree uc = new grouping_employees_by_degree();
                    if (this.sort_checkBox.IsChecked == true)
                        uc.Source = bl.degree_employees(true);
                    else
                        uc.Source = bl.degree_employees();
                    this.page.Content = uc;
                }
            }
        }
    }
}
