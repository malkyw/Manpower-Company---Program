﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for getFunctions.xaml
    /// </summary>
    public partial class getFunctions : Window
    {
        BL.IBL bl;

        public getFunctions()//ctor
        {
            bl = BL.Factory_BL.GetBL();
            InitializeComponent();
            this.function_comboBox.ItemsSource = bl.getNameFunctions();
            this.choose_employer_comboBox.ItemsSource = bl.get_employers();
            this.choose_employer_comboBox.DisplayMemberPath = "Id_number";
            this.choose_employer_comboBox.SelectedValuePath = "Id_number";
            this.choose_employer_comboBox.Visibility = System.Windows.Visibility.Collapsed;
            this.choose_employer_label.Visibility = System.Windows.Visibility.Collapsed;
        }

        private string GetSelectedFunc()
        {
            object result = this.function_comboBox.Text;

            return (string)result;
        }

        private void Do_button_Click(object sender, RoutedEventArgs e)
        {
            string result = GetSelectedFunc();
            if (result == null)
                MessageBox.Show("must select a function.");
            else
            {
                if (result as string == "get specializiations")
                {
                    showAllEmployees uc = new showAllEmployees();
                    uc.Source = bl.get_specializiations();
                    this.page.Content = uc;
                }
                if (result as string == "get contracts")
                {
                    showAllEmployees uc = new showAllEmployees();
                    uc.Source = bl.get_Contracts();
                    this.page.Content = uc;
                }
                if (result as string == "get employees")
                {
                    showAllEmployees uc = new showAllEmployees();
                    uc.Source = bl.get_employees();
                    this.page.Content = uc;
                }
                if (result as string == "get employers")
                {
                    showAllEmployees uc = new showAllEmployees();
                    uc.Source = bl.get_employers();
                    this.page.Content = uc;
                }

                if (result as string == "get profit for year")
                {
                    showAllEmployees uc = new showAllEmployees();
                    uc.Source = bl.profit_per_year();
                    this.page.Content = uc;
                }

                if (result as string == "get employees by employer")
                {
                    string id = this.choose_employer_comboBox.Text;
                    showAllEmployees uc = new showAllEmployees();
                    uc.Source = bl.employees_to_employer(id);
                    this.page.Content = uc;
                }

                if (result as string == "get banks")
                {
                    showAllEmployees uc = new showAllEmployees();
                    uc.Source = bl.get_banks();
                    this.page.Content = uc;
                }
                if (result as string == "get specilaizations ordered")
                {
                    showAllEmployees uc = new showAllEmployees();
                    uc.Source = bl.spcialization_ordered();
                    this.page.Content = uc;
                }

            }
        }

        private void function_comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string result = (string)(sender as ComboBox).SelectedItem;
            if (result == "get employees by employer")
            {
                this.choose_employer_comboBox.Visibility = System.Windows.Visibility.Visible;
                this.choose_employer_label.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                this.choose_employer_comboBox.Visibility = System.Windows.Visibility.Collapsed;
                this.choose_employer_label.Visibility = System.Windows.Visibility.Collapsed;
            }
        }

    }
}
