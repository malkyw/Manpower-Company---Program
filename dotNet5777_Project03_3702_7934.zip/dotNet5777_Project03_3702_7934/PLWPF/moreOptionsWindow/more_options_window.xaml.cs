﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
namespace PLWPF
{
    /// <summary>
    /// Interaction logic for more_options_window.xaml
    /// </summary>
    public partial class more_options_window : Window
    {

        public more_options_window()
        {
            InitializeComponent();

        }


        private void button1_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Window grouping = new allFunctions();
            grouping.ShowDialog();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Window get = new getFunctions();
            get.ShowDialog();
        }
    }
}






