﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for AddContractWindow.xaml
    /// </summary>

    public partial class AddUpdateContractWindow : Window
    {
        BL.IBL bl;
        BE.Contract cont;
        BE.Contract tmp;
        public AddUpdateContractWindow()//defult ctor
        {
            InitializeComponent();
        }

        public AddUpdateContractWindow(string sender)//parameter ctor
        {
            InitializeComponent();
            
            cont = new BE.Contract();
            this.grid1.DataContext = cont;
            this.num_up_down.Value = cont.Num_hours_of_work;
            bl = BL.Factory_BL.GetBL();

            this.employee_id_comboBox.ItemsSource = bl.get_employees();
            this.employee_id_comboBox.DisplayMemberPath = "Id_number";
            this.employee_id_comboBox.SelectedValuePath = "Id_number";

            this.employer_id_comboBox.ItemsSource = bl.get_employers();
            this.employer_id_comboBox.DisplayMemberPath = "Id_number";
            this.employer_id_comboBox.SelectedValuePath = "Id_number";

            this.cont_number_comboBox.ItemsSource = bl.get_Contracts();
            this.cont_number_comboBox.DisplayMemberPath = "Contract_number";
            this.cont_number_comboBox.SelectedValuePath = "Contract_number";

            if (sender == "add")
            {
                //if the employee combobox is empty then message and close the window
                if (this.employee_id_comboBox.Items.Count == 0)
                {
                    MessageBox.Show("There are no employees to sign a contract.");
                    this.Close();
                }
                //if the employer combobox is empty then message and close the window
                if (this.employer_id_comboBox.Items.Count == 0)
                {
                    MessageBox.Show("There are no employers to sign a contract.");
                    this.Close();
                }
                this.Title = "add contract";
                this.title_lebel.Content = "add new contract";
                this.AddButton.Content = "add";
                this.contractLabel.Visibility = System.Windows.Visibility.Collapsed;
                this.cont_number_comboBox.Visibility = System.Windows.Visibility.Collapsed;
            }
            if (sender == "update")
            {
                //if the contract number combobox is empty then message and close the window
                if (this.cont_number_comboBox.Items.Count == 0)
                {
                    MessageBox.Show("There are no contracts to update.");
                    this.Close();
                }
                this.Title = "update contract";
                this.title_lebel.Content = "update contract";
                this.AddButton.Content = "update";
                this.beginning_of_workDatePicker.IsEnabled = false;
                this.had_interviewedCheckBox.IsEnabled = false;
                this.had_sighed_contractCheckBox.IsEnabled = false;
                this.num_up_down. IsEnabled = false;
                this.end_of_workDatePicker.IsEnabled = false;
                this.employee_id_comboBox.IsEnabled = false;
                this.employer_id_comboBox.IsEnabled = false;
              
                
            }
        
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)//add-update
        {

            try
            {
                if (this.beginning_of_workDatePicker.Text.CompareTo(this.end_of_workDatePicker.Text) > 0)
                {
                    MessageBox.Show("end of work date must be after beginnig of work date.");
                    return;
                }
                if ((string)(sender as Button).Content == "add")
                {
                    cont.Num_hours_of_work = this.num_up_down.Value;
                    string number = bl.add_contract(cont);//returns the new contract number
                    cont = new BE.Contract();
                    this.grid1.DataContext = cont;
                    
                    MessageBox.Show(string.Format("the contract {0} was added.", number));
                }

                else//update
                {
                    tmp.Num_hours_of_work = this.num_up_down.Value;
                    bl.update_Contract(tmp);
                    cont = new BE.Contract();
                    this.num_up_down.Value = cont.Num_hours_of_work;
                    MessageBox.Show(string.Format("the contract {0} was updated.", this.cont_number_comboBox.Text));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void contract_info(object sender, SelectionChangedEventArgs e)//return to window the contract information
        {
            object result = this.cont_number_comboBox.SelectedValue;
               
               cont = bl.get_contract(result as string);
                if (cont != null)//the contract exists
                {
                    tmp = new BE.Contract();
                    //for deep copying
                    #region tmp=cont
                    tmp.Had_interviewed = cont.Had_interviewed;
                    tmp.Had_sighed_contract = cont.Had_sighed_contract;
                    tmp.Num_hours_of_work = cont.Num_hours_of_work;
                    tmp.Rate_per_hour_gross = cont.Rate_per_hour_gross;
                    tmp.Rate_per_hour_net = cont.Rate_per_hour_net;
                    tmp.Beginning_of_work = cont.Beginning_of_work;
                    tmp.Contract_number = cont.Contract_number;
                    tmp.Employee_id = cont.Employee_id;
                    tmp.Employer_id = cont.Employer_id;
                    tmp.End_of_work = cont.End_of_work;
                    #endregion 
                    this.grid1.DataContext = tmp;
                    this.num_up_down.Value = tmp.Num_hours_of_work;
                    this.cont_number_comboBox.IsEnabled = true;
                    this.beginning_of_workDatePicker.IsEnabled = true;
                    this.employeeId.Foreground = Brushes.Gray;
                    this.employee_id_comboBox.Foreground = Brushes.Gray;
                    this.employerId.Foreground = Brushes.Gray;
                    this.employer_id_comboBox.Foreground = Brushes.Gray;
                    this.had_interviewedCheckBox.IsEnabled = true;
                    this.had_sighed_contractCheckBox.IsEnabled = true;
                    this.num_up_down.IsEnabled = true;
                    this.end_of_workDatePicker.IsEnabled = true;
                }
                else
                    MessageBox.Show(string.Format("the contract {0} does not exists.",cont.Contract_number));
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void num_up_down_Loaded(object sender, RoutedEventArgs e)
        {
            (sender as NumericUpDownControl).Value = 1;
        }
    }
}
