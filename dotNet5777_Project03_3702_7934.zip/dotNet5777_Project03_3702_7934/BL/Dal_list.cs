﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace DAL
{
    internal class Dal_list : IDAL
    {
        DS.DataSource data;
        public Dal_list()
        {
            data = new DS.DataSource();
            // public static List<string> function_name = new List<string> { "get specializiations", "get contracts", "get employers", "get employees", "get profit for year", "get employees by employer", "get banks", "get specilaizations ordered" };
            
            #region initionlize bank list
            DS.DataSource. bank_list.Add(new BankAccount
            {
                BankNumber = 12345,
                BankName = "pagi",
                BankBranchNumber = 85,
                BranchAddress = "gadera 6",
                BranchCity = "jerusalem",
                AccountNumber = 212345,
            });

            DS.DataSource.bank_list.Add(new BankAccount
            {
                BankNumber = 23451,
                BankName = "poalim",
                BankBranchNumber = 44,
                BranchAddress = "gani varsha 6",
                BranchCity = "bni brak",
                AccountNumber = 456732,
            });

            DS.DataSource.bank_list.Add(new BankAccount
            {
                BankNumber = 76543,
                BankName = "poalim",
                BankBranchNumber = 55,
                BranchAddress = "samgar 16",
                BranchCity = "jerusalem",
                AccountNumber = 876543,
            });

            DS.DataSource.bank_list.Add(new BankAccount
            {
                BankNumber = 98754,
                BankName = "yahav",
                BankBranchNumber = 32,
                BranchAddress = "tel aviv 54",
                BranchCity = "tel aviv",
                AccountNumber = 4565322,
            });

            DS.DataSource.bank_list.Add(new BankAccount
            {
                BankNumber = 65432,
                BankName = "discont",
                BankBranchNumber = 54,
                BranchAddress = "jafo",
                BranchCity = "jerosalem",
                AccountNumber = 4567642,
            });
            #endregion
        }
        public static Random rand = new Random();


        #region add functions

        

        public void add_contract(Contract to_add)
        { 
            DS.DataSource.contract_list.Add(to_add);
        }

        public void add_employee(Employee to_add)
        {
            Employee temp = DS.DataSource.employees_list.Find(e => e.Id_number == to_add.Id_number);
            if (temp != null)
                throw new Exception("an employee with the same ID number already exists.\n");
            DS.DataSource.employees_list.Add(to_add);
        }

        public void add_employer(Employer to_add)
        {
            Employer temp = DS.DataSource.employers_list.Find(e => e.Id_number == to_add.Id_number);
            if (temp != null)
                throw new Exception("an employer with the same ID number already exists.\n");
            DS.DataSource.employers_list.Add(to_add);
        }

        
         
        public void add_specialization(Specialization to_add)
        {
            DS.DataSource.specializations_list.Add(to_add);
        }

        #endregion

        #region delete functions

        public void delete_contract(string id)
        {
            Contract temp = get_contract(id);
            if (temp == null)
                throw new Exception("a contract with this number does not exists.\n");
            DS.DataSource.contract_list.Remove(temp);
        }

        public void delete_employee(string id)
        {
            Employee temp = get_employee(id);
            if (temp == null)
                throw new Exception("an employee with this ID number does not exists.\n");
            DS.DataSource.contract_list.RemoveAll(c => c.Employee_id == id);
            DS.DataSource.employees_list.Remove(temp);
        }

        public void delete_employer(string id)
        {
            Employer temp = get_employer(id);
            if (temp == null)
                throw new Exception("an employer with this ID number does not exists.\n");
            DS.DataSource.contract_list.RemoveAll(c => c.Employer_id == id);
            DS.DataSource.employers_list.Remove(temp);
        }

        public void delete_specializiation(string id)
        {
            Specialization temp = get_specialization(id);
            if (temp == null)
                throw new Exception("a Specialization with this number does not exists.\n");
            if(get_employees(e=>e.Speciality_number==id).Any())
                throw new Exception("the Specialization is used by some employees!!!\n");
            DS.DataSource.specializations_list.Remove(temp);
        }
        #endregion

        #region list get function

        public IEnumerable<Contract> get_Contracts(Func<Contract,bool> predicate=null)
        {
            if (predicate == null)
                return DS.DataSource.contract_list.AsEnumerable();

            return DS.DataSource.contract_list.Where(predicate);
        }

        public IEnumerable<Employee> get_employees(Func<Employee, bool> predicate = null)
        {
            if (predicate == null)
                return DS.DataSource.employees_list.AsEnumerable();
            return DS.DataSource.employees_list.Where(predicate);
        }

        public IEnumerable<Employer> get_employers(Func<Employer, bool> predicate = null)
        {
            if (predicate == null)
                return DS.DataSource.employers_list.AsEnumerable();
            return DS.DataSource.employers_list.Where(predicate);
        }

        public IEnumerable<Specialization> get_specializiations(Func<Specialization, bool> predicate = null)
        {
            if (predicate == null)
                return DS.DataSource.specializations_list.AsEnumerable();
            return DS.DataSource.specializations_list.Where(predicate);
        }
        #endregion

        #region update functions

        public void update_Contract(Contract to_update)
        {
            int index = DS.DataSource.contract_list.FindIndex(c => c.Contract_number == to_update.Contract_number);
            if (index == -1)
                throw new Exception("contract with this number not found.\n");
            DS.DataSource.contract_list[index].Contract_number = to_update.Contract_number;
            DS.DataSource.contract_list[index].Employee_id = to_update.Employee_id;
            DS.DataSource.contract_list[index].Employer_id = to_update.Employer_id;
            DS.DataSource.contract_list[index].Beginning_of_work = to_update.Beginning_of_work;
            DS.DataSource.contract_list[index].End_of_work = to_update.End_of_work;
            DS.DataSource.contract_list[index].Had_interviewed = to_update.Had_interviewed;
            DS.DataSource.contract_list[index].Had_sighed_contract = to_update.Had_sighed_contract;
            DS.DataSource.contract_list[index].Num_hours_of_work = to_update.Num_hours_of_work;
            DS.DataSource.contract_list[index].Rate_per_hour_gross = to_update.Rate_per_hour_gross;
            DS.DataSource.contract_list[index].Rate_per_hour_net = to_update.Rate_per_hour_net;

        }

        public void update_employee(Employee to_update)
        {
            int index = DS.DataSource.employees_list.FindIndex(e => e.Id_number == to_update.Id_number);
            if (index == -1)
                throw new Exception("employee with this ID number not found.\n");
            DS.DataSource.employees_list[index].Id_number = to_update.Id_number;
            DS.DataSource.employees_list[index].First_name = to_update.First_name;
            DS.DataSource.employees_list[index].Last_name = to_update.Last_name;
            DS.DataSource.employees_list[index].Birth_date = to_update.Birth_date;
            DS.DataSource.employees_list[index].Phone_number = to_update.Phone_number;
            DS.DataSource.employees_list[index].Address = to_update.Address;
            DS.DataSource.employees_list[index].Accademic_degree = to_update.Accademic_degree;
            DS.DataSource.employees_list[index].Army_graduate = to_update.Army_graduate;
            DS.DataSource.employees_list[index].Experiance = to_update.Experiance;
            DS.DataSource.employees_list[index].Bank_information = to_update.Bank_information;
            DS.DataSource.employees_list[index].Speciality_number = to_update.Speciality_number;
            DS.DataSource.employees_list[index].Recommemdations = to_update.Recommemdations;
        }

        public void update_employer(Employer to_update)
        {
            int index = DS.DataSource.employers_list.FindIndex(e => e.Id_number == to_update.Id_number);
            if (index == -1)
                throw new Exception("employer with this ID number not found.\n");
            DS.DataSource.employers_list[index].Id_number = to_update.Id_number;
            DS.DataSource.employers_list[index].IsPrivate = to_update.IsPrivate;
            DS.DataSource.employers_list[index].First_name = to_update.First_name;
            DS.DataSource.employers_list[index].Last_name = to_update.Last_name;
            DS.DataSource.employers_list[index].CompanyName = to_update.CompanyName;
            DS.DataSource.employers_list[index].Phone_number = to_update.Phone_number;
            DS.DataSource.employers_list[index].Address = to_update.Address;
            DS.DataSource.employers_list[index].OccupationField = to_update.OccupationField;
            DS.DataSource.employers_list[index].BusinessCreationDate = to_update.BusinessCreationDate;
        }

        public void update_specializiation(Specialization to_update)
        {
            int index = DS.DataSource.specializations_list.FindIndex(s => s.Speciality_number == to_update.Speciality_number);
            if (index == -1)
                throw new Exception("specialization with this number not found.\n");
            DS.DataSource.specializations_list[index].Speciality_number = to_update.Speciality_number;
            DS.DataSource.specializations_list[index].SpecialityField = to_update.SpecialityField;
            DS.DataSource.specializations_list[index].Speciality_name = to_update.Speciality_name;
            DS.DataSource.specializations_list[index].MinRatePerHour = to_update.MinRatePerHour;
            DS.DataSource.specializations_list[index].MaxRatePerHour = to_update.MaxRatePerHour;
        }
        #endregion
       
        #region get functions

        public Specialization get_specialization(string id)
        {
            return DS.DataSource.specializations_list.Find(s => s.Speciality_number == id);
        }

        public Employee get_employee(string id)
        {
            return DS.DataSource.employees_list.Find(e => e.Id_number == id);
        }

        public Employer get_employer(string id)
        {
            return DS.DataSource.employers_list.Find(e => e.Id_number == id);
        }

        public Contract get_contract(string id)
        {
            return DS.DataSource.contract_list.Find(c => c.Contract_number == id);
        }


        public IEnumerable<BankAccount> get_banks(Func<BankAccount, bool> predicate = null)
        {

            if (predicate == null)
                return DS.DataSource.bank_list.AsEnumerable<BankAccount>();
            else
                return DS.DataSource.bank_list.Where(predicate);

        }
        #endregion

        static int s_number = 10000000;
        public void give_spiciality_number(BE.Specialization spec)
        {
            s_number += 1;//קוד ייחודי רץ בן 8 ספרות
            spec.Speciality_number = Convert.ToString(s_number);
        }
        static int c_number =10000000;
        public  void give_contract_number(BE.Contract cont)
        {
            c_number += 1;//קוד ייחודי רץ בן 8 ספרות
            cont.Contract_number = Convert.ToString (c_number);//does not check if exists becouse the id is a new id(static number)
        }

        public IEnumerable<BankAccount> GetAllAtm()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IGrouping<string, BankAccount>> GetAllAtmGroupByBank()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> GetAllBankNames()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BankAccount> GetAllBankbranches(string bankName)
        {
            throw new NotImplementedException();
        }
    }
}

