﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
   public interface IBL
    {
        void add_specialization(BE.Specialization to_add);
        void delete_specializiation(string id);
        void update_specializiation(BE.Specialization to_update);
        BE.Specialization get_specialization(string id);
        IEnumerable<BE.Specialization> get_specializiations(Func<BE.Specialization, bool> predicate = null);

        void add_employee(BE.Employee to_add);
        void delete_employee(string id);
        void update_employee(BE.Employee to_update);
        BE.Employee get_employee(string id);
        IEnumerable<BE.Employee> get_employees(Func<BE.Employee, bool> predicate = null);

        void add_employer(BE.Employer to_add);
        void delete_employer(string id);
        void update_employer(BE.Employer to_update);
        BE.Employer get_employer(string id);
        IEnumerable<BE.Employer> get_employers(Func<BE.Employer, bool> predicate = null);

        string add_contract(BE.Contract to_add);
        void delete_contract(string id);
        void update_Contract(BE.Contract to_update);
        BE.Contract get_contract(string id);
        IEnumerable<BE.Contract> get_Contracts(Func<BE.Contract, bool> predicate = null);

        IEnumerable<int> get_bank_branches(string bank_name);
        IEnumerable<BE.BankAccount> get_banks(string name = null);
        IEnumerable<string> get_bank_names(Func<BE.BankAccount, bool> predicate = null);
        IEnumerable<BE.BankAccount> get_branch(string bank, int branch);
        int get_num_contrct(Func<BE.Contract, bool> predicate = null);//return the num contract for a predicate
        BE.Specialization speciality_type(BE.Contract c);

        IEnumerable<IGrouping<string,BE.Contract>> spcialization_contracts(bool sort = false);
        IEnumerable<IGrouping<string, BE.Contract>> city_contracts(bool sort = false);
        IEnumerable profit_per_year();
        IEnumerable<IGrouping<string, BE.Employee>> spcialization_employees(bool sort = false);
        IEnumerable<IGrouping<BE.enumClass.academic_state, BE.Employee>> degree_employees(bool sort = false);
        IEnumerable<IGrouping<bool, BE.Employee>> Army_graduate(bool sort = false);
        IEnumerable<IGrouping<bool, BE.Employer>> privet_employers(bool sort = false);
        IOrderedEnumerable<BE.Specialization> spcialization_ordered();
        IEnumerable<BE.Employee> employees_to_employer(string employer_id);
        double calculate_grooss_hourly_salery(string employee_id);
        List<string> getNameFunctions();

    }
}
