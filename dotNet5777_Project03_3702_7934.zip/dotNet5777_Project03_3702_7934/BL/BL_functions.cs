﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using System.Collections;

namespace BL
{
    internal class BL_functions : IBL
    {
        DAL.IDAL dal;
        #region initionlize functions list
        List<string> function_name_list = new List<string>()
            {
                "get specializiations",
                "get contracts",
                "get employers",
                "get employees",
                "get profit for year",
                "get employees by employer",
                "get banks",
                "get specilaizations ordered"
           };
        #endregion
        public BL_functions()//factory
        {
            dal = DAL.FactoryDal.getDal();
           init();

        }
        #region add function
        /// <summary>
        /// add contract- checks if the contract is a single contract and the detils are corrcet and exist
        /// </summary>
        /// <param name="to_add"></param>
        public string add_contract(Contract to_add)
        {
            dal.give_contract_number(to_add);
            Employer emp = get_employer(to_add.Employer_id);
            if (emp == null)
                throw new Exception("the employer in the given contract does not exist in our employers database.\n");
            if (dal.get_employee(to_add.Employee_id)== null)
                throw new Exception("the employee in the given contract does not exist in our employees database.\n");
            if(emp.BusinessCreationDate > DateTime.Now.AddYears(-1))
                throw new Exception("cannot sign a contract with a business that is less than a year old .\n");
          double gross_rate = calculate_grooss_hourly_salery(to_add.Employee_id);
            to_add.Rate_per_hour_gross = gross_rate;
            double net_rate = calculate_net_rate(to_add);
            Specialization speciality_rate = speciality_type(to_add);
            if (net_rate < speciality_rate.MinRatePerHour)
                net_rate = speciality_rate.MinRatePerHour;
            if(net_rate > speciality_rate.MaxRatePerHour)
                net_rate = speciality_rate.MaxRatePerHour;
            
            to_add.Rate_per_hour_net = net_rate;
            to_add.Had_sighed_contract = true;
            dal.add_contract(to_add);
            return to_add.Contract_number;
        }

        /// <summary>
        /// adds an employee over 18 years old whith recommendations
        /// </summary>
        /// <param name="to_add"></param>
        public void add_employee(Employee to_add)
        {
            if (DateTime.Now.AddYears(-18) < to_add.Birth_date)
                throw new Exception("the employee is yonger than 18 years.\n");
            if (to_add.Recommemdations==""||to_add.Recommemdations==null)//if the employee does not have המלצותthen throw
                throw new Exception("the employee most have recommendations.\n");
            if (to_add.Speciality_number == "" || to_add.Speciality_number == null)//if the employee does not have המלצותthen throw
                throw new Exception("the employee most have a speciality number.\n");

            IEnumerable<int> branches = get_bank_branches(to_add.Bank_information.BankName);//get all branches of this bank
            bool flag = false;
            foreach (int item in branches)//look in the list of branch numbers and see if the bank branch number exsist than add 
                if (item == to_add.Bank_information.BankBranchNumber)
                {
                    dal.add_employee(to_add);
                    flag = true;
                }
            if (flag == false)
                throw new Exception("the bank information is not correct\n");//does not exsit
        }

        /// <summary>
        ///  adds an employer change first name to privet or minster
        /// </summary>
        /// <param name="to_add"></param>
        public void add_employer(Employer to_add)
        {
            dal.add_employer(to_add);
        }

        public void add_specialization(Specialization to_add)
        {
            dal.give_spiciality_number(to_add);
            dal.add_specialization(to_add);
        }
        #endregion

        #region delete function
        public void delete_contract(string id)
        {
            dal.delete_contract(id);
        }

        /// <summary>
        /// deletes the employee and the contract he is sighned to
        /// </summary>
        /// <param name="id"></param>
        public void delete_employee(string id)
        {
            dal.delete_employee(id);
        }

        /// <summary>
        /// deletes the employer and the  contract he is sighend to
        /// </summary>
        /// <param name="id"></param>
        public void delete_employer(string id)
        {
            dal.delete_employer(id);
        }

        /// <summary>
        /// deletes specialization and the employee whith that spec.
        /// </summary>
        /// <param name="id"></param>
        public void delete_specializiation(string id)
        {
            dal.delete_specializiation(id);
        }
        #endregion

        #region get_ list functions
        public List<string> getNameFunctions()
        {
            return function_name_list;
        }
        public IEnumerable<Contract> get_Contracts(Func<Contract, bool> predicate = null)
        {
            return dal.get_Contracts(predicate);
        }

        public IEnumerable<Employee> get_employees(Func<Employee, bool> predicate = null)
        {
            return dal.get_employees(predicate);
        }

        public IEnumerable<Employer> get_employers(Func<Employer, bool> predicate = null)
        {
            return dal.get_employers(predicate);
        }

        public IEnumerable<Specialization> get_specializiations(Func<Specialization, bool> predicate = null)
        {
            return dal.get_specializiations(predicate);
        }
        #endregion

        #region update functions
        /// <summary>
        /// like add
        /// </summary>
        /// <param name="to_update"></param>
        public void update_Contract(Contract to_update)
        {
            Employer emp = dal.get_employer(to_update.Employer_id);
            if (emp == null)
                throw new Exception("the employer in the given contract does not exist in our employers database.\n");
            if (dal.get_employee(to_update.Employee_id) == null)
                throw new Exception("the employee in the given contract does not exist in our employees database.\n");
            if (emp.BusinessCreationDate > DateTime.Now.AddYears(-1))
                throw new Exception("cannot sign a contract with a business that is less than a year old .\n");
            double gross_rate = calculate_grooss_hourly_salery(to_update.Employee_id);
            to_update.Rate_per_hour_gross = gross_rate;
            double net_rate = calculate_net_rate(to_update);
            Specialization speciality_rate = speciality_type(to_update);
            if (net_rate < speciality_rate.MinRatePerHour)
                net_rate = speciality_rate.MinRatePerHour;
            if (net_rate > speciality_rate.MaxRatePerHour)
                net_rate = speciality_rate.MaxRatePerHour;
            to_update.Rate_per_hour_net = net_rate;
            to_update.Had_sighed_contract = true;
            dal.update_Contract(to_update);
        }

        public void update_employee(Employee to_update)
        {
            if (DateTime.Now.AddYears(-18) < to_update.Birth_date)
                throw new Exception("the employee is yonger than 18 years.\n");
            if (to_update.Recommemdations == "" || to_update.Recommemdations == null)//if the employee does not have המלצותthen throw
                throw new Exception("the employee most have recommendations.\n");

            //IEnumerable<int> branches = get_bank_branches(b => b.BankName == to_update.Bank_information.BankName);//get all branches of this bank
            //foreach (int item in branches)//look in the list of branch numbers and see if the bank branch number exsist than add 
            //    if (item == to_update.Bank_information.BankBranchNumber)
            //    {
                    dal.update_employee(to_update);
                    //return;
                //}
            //throw new Exception("the bank information is not correct\n");//does not exsit
        }

        public void update_employer(Employer to_update)
        {
            if (to_update.IsPrivate)
                to_update.CompanyName = "private owner";
            else
                to_update.First_name = to_update.Last_name = "minister";
            dal.update_employer(to_update);
        }

        public void update_specializiation(Specialization to_update)
        {
            dal.update_specializiation(to_update);
        }
        #endregion

        #region calculate rate per hour

        /// <summary>
        /// caclcuates the contract forthe wanted employee
        /// </summary>
        /// <param name="employee_id"></param>
        /// <returns></returns>
        public int calculate_employee_contracts(string employee_id)//counts the number of employee contracts
        {
            int number_of_contracts=0;
           //
            var all_employee_contracts = from Employee item in get_employees().ToList()
                                         where item.Id_number == employee_id
                                         select item;
            foreach (var item in all_employee_contracts)
                number_of_contracts++;
            return number_of_contracts;
        }
       
        /// <summary>
        /// caclculates the contracts for a wanted employer
        /// </summary>
        /// <param name="employer_id"></param>
        /// <returns></returns>
        public int calculate_employer_contracts(string employer_id)
        {
            int number_of_contracts = 0;

            var all_employer_contracts = from Employer item in get_employers()
                                         where item.Id_number == employer_id
                                         select item;
            foreach (var item in all_employer_contracts)
                number_of_contracts++;
            return number_of_contracts;
        }

        /// <summary>
        /// caclculates the commission- by the num employee cont and num employer cont- retruns the lower commision 
        /// </summary>
        /// <param name="employee_cont"></param>
        /// <param name="employer_cont"></param>
        /// <returns></returns>
        public double calculate_commission(int employee_cont, int employer_cont)
        {
            double employee_commission = 10.5;
            if (employee_cont == 1)
                employee_commission = 8.5;
            if (employee_cont == 2)
                employee_commission = 7.5;
            if (employee_cont > 2)
                employee_commission = 5.5;

            double employer_commission = 10.5;
            if (employer_cont > 1)
                employer_commission = 9.5;
            if (employer_cont > 5)
                employer_commission = 7.5;
            if (employer_cont > 10)
                employer_commission = 5.5;
            if (employer_cont > 20)
                employer_commission = 3.5;

            return employee_commission < employer_commission ? employee_commission : employer_commission;
        }
        
        /// <summary>
        /// calculats net rate by the gross-comission
        /// </summary>
        /// <param name="to_clculate"></param>
        /// <returns> </returns>
        public double calculate_net_rate(Contract to_clculate)
        {
            int cont_employee = calculate_employee_contracts(to_clculate.Employee_id);
            int cont_employer = calculate_employer_contracts(to_clculate.Employer_id);
            double commission = (calculate_commission(cont_employee, cont_employer));
            double net = (to_clculate.Rate_per_hour_gross -(commission / 100.0) * to_clculate.Rate_per_hour_gross);
            return (net);//neto=bruto-commission%
        }
        #endregion

        #region init
        void init()
        {
            ////#region init specialization

            ////this.add_specialization(new Specialization
            ////{
            ////    Speciality_number = "0",
            ////    SpecialityField = enumClass.specializatinFailed.information_systems,
            ////    Speciality_name = "dotnet",
            ////    MinRatePerHour = 40,
            ////    MaxRatePerHour = 200,
            ////});
            ////this.add_specialization(new Specialization
            ////{
            ////    Speciality_number = "0",
            ////    SpecialityField = enumClass.specializatinFailed.infuastructure_computers,
            ////    Speciality_name = "c++",
            ////    MinRatePerHour = 70,
            ////    MaxRatePerHour = 300,
            ////});
            ////this.add_specialization(new Specialization
            ////{
            ////    Speciality_number = "0",
            ////    SpecialityField = enumClass.specializatinFailed.QA,
            ////    Speciality_name = "c#",
            ////    MinRatePerHour = 40,
            ////    MaxRatePerHour = 200,
            ////});
            ////#endregion

            ////#region init employee
            ////this.add_employee(new Employee
            ////{
            ////    Id_number = "234567890",
            ////    First_name = "moshe",
            ////    Last_name = "levi",
            ////    Birth_date = new DateTime(1993, 08, 26),
            ////    Phone_number = "0527173794",
            ////    Address = "hamem gimel 33",
            ////    Accademic_degree = enumClass.academic_state.PHD,
            ////    Army_graduate = false,
            ////    Experiance = 5,
            ////    //        //    Bank_information = new BankAccount { BankNumber = 12345, BankName = "pagi", BankBranchNumber = 85, BranchAddress = "gadera 6", BranchCity = "jerusalem", AccountNumber = 212345 },
            ////    Speciality_number = "10000001",
            ////    Recommemdations = "aaa",
            ////});
            ////this.add_employee(new Employee
            ////{
            ////    Id_number = "345678901",
            ////    First_name = "david",
            ////    Last_name = "levi",
            ////    Birth_date = new DateTime(1989, 12, 27),
            ////    Phone_number = "0527167685",
            ////    Address = "hamem gimel 25",
            ////    Accademic_degree = enumClass.academic_state.PHD,
            ////    Army_graduate = false,
            ////    Experiance = 8,
            ////    //        //    Bank_information = new BankAccount { BankNumber = 23451, BankName = "poalim", BankBranchNumber = 44, BranchAddress = "gani varsha 6", BranchCity = "bni brak", AccountNumber = 456732 },
            ////    Speciality_number = "10000002",
            ////    Recommemdations = "aaa",
            ////});
            ////this.add_employee(new Employee
            ////{
            ////    Id_number = "456789012",
            ////    First_name = "yaacove",
            ////    Last_name = "kohen",
            ////    Birth_date = new DateTime(1970, 11, 26),
            ////    Phone_number = "0527175437",
            ////    Address = "bnay brak 34",
            ////    Accademic_degree = enumClass.academic_state.PHD,
            ////    Army_graduate = true,
            ////    Experiance = 15,
            ////    //        //    Bank_information = new BankAccount { BankNumber = 98754, BankName = "yahav", BankBranchNumber = 32, BranchAddress = "tel aviv 54", BranchCity = "tel aviv", AccountNumber = 4565322 },
            ////    Speciality_number = "10000003",
            ////    Recommemdations = "aaa",
            ////});
            ////#endregion

            ////#region init employer
            ////this.add_employer(new Employer
            ////{
            ////    Id_number = "123456789",
            ////    IsPrivate = false,
            ////    First_name = "no",
            ////    Last_name = "no",
            ////    CompanyName = "intel",
            ////    Phone_number = "0527173694",
            ////    Address = "har hotzvim",
            ////    OccupationField = enumClass.specializatinFailed.hardwere_engineereing,
            ////    BusinessCreationDate = new DateTime(2000, 1, 12),
            ////});

            ////this.add_employer(new Employer
            ////{
            ////    Id_number = "123666789",
            ////    IsPrivate = true,
            ////    First_name = "moshe",
            ////    Last_name = "israel",
            ////    CompanyName = "",
            ////    Phone_number = "0554173694",
            ////    Address = "kanfey neshrim",
            ////    OccupationField = enumClass.specializatinFailed.QA,
            ////    BusinessCreationDate = new DateTime(1990, 6, 10),
            ////});

            ////this.add_employer(new Employer
            ////{
            ////    Id_number = "123456889",
            ////    IsPrivate = false,
            ////    First_name = "no",
            ////    Last_name = "no",
            ////    CompanyName = "cisco",
            ////    Phone_number = "0529973694",
            ////    Address = "har hotzvim",
            ////    OccupationField = enumClass.specializatinFailed.information_systems,
            ////    BusinessCreationDate = new DateTime(1950, 1, 1),
            ////});
            ////#endregion

            ////#region  init contract
            ////this.add_contract(new Contract
            ////{
            ////    Contract_number = "0",
            ////    Employer_id = "123456789",
            ////    Employee_id = "234567890",
            ////    Had_interviewed = true,
            ////    Had_sighed_contract = false,
            ////    Rate_per_hour_gross = 60,
            ////    Rate_per_hour_net = 40,
            ////    Num_hours_of_work = 120,
            ////    Beginning_of_work = new DateTime(2012, 7, 10),
            ////    End_of_work = new DateTime(2016, 7, 10),
            ////});

            ////this.add_contract(new Contract
            ////{
            ////    Contract_number = "0",
            ////    Employer_id = "123456789",
            ////    Employee_id = "345678901",
            ////    Had_interviewed = true,
            ////    Had_sighed_contract = true,
            ////    Rate_per_hour_gross = 70,
            ////    Rate_per_hour_net = 55,
            ////    Num_hours_of_work = 160,
            ////    Beginning_of_work = new DateTime(2014, 8, 9),
            ////    End_of_work = new DateTime(2017, 8, 9),
            ////});

            ////this.add_contract(new Contract
            ////{
            ////    Contract_number = "0",
            ////    Employer_id = "123456889",
            ////    Employee_id = "456789012",
            ////    Had_interviewed = false,
            ////    Had_sighed_contract = true,
            ////    Rate_per_hour_gross = 75,
            ////    Rate_per_hour_net = 60,
            ////    Num_hours_of_work = 150,
            ////    Beginning_of_work = new DateTime(2012, 11, 10),
            ////    End_of_work = new DateTime(2018, 11, 10),
            ////});
            ////#endregion

        }
        #endregion

        #region get_functions
        public Contract get_contract(string id)
        {
            return dal.get_contract(id);
        }

        public Employee get_employee(string id)
        {
            return dal.get_employee(id);
        }

        public Employer get_employer(string id)
        {
            return dal.get_employer(id);
        }

        public Specialization get_specialization(string id)
        {
            return dal.get_specialization(id);
        }

        #endregion

        #region bank functions
        public IEnumerable<int> get_bank_branches(string bank_name)
        {
            var bank_branches1 = from b in dal.GetAllBankbranches(bank_name).ToList()
                                orderby b.BankBranchNumber 
                                select b.BankBranchNumber ;
            List<int> bank_branches = new List<int>();
            int tmp = bank_branches1.First();
            foreach (var item in bank_branches1)
            {
                if (item != tmp)
                {
                    bank_branches.Add(tmp);
                    tmp = item;
                }
            }
            return bank_branches;
        }
   
        public IEnumerable<string> get_bank_names(Func<BE.BankAccount, bool> predicate = null)
        {
            return dal.GetAllBankNames();
        }

        public IEnumerable<BE.BankAccount> get_banks(string name=null)
        {
            IEnumerable banks;
            if (name != null)
            {
                banks = from item in dal.GetAllAtm()
                        where (item.BankName == name)
                        select item; 
            }
           return dal.GetAllAtm();
        }


        public IEnumerable<BE.BankAccount> get_branch(string bank,int branch)
        {
            var banks = get_banks(bank);
            var branches = from item in banks
                           where item.BankBranchNumber == branch
                           select item;
            return branches;
        }
        #endregion

        /// <summary>
        /// returns number of  contracts
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public int get_num_contrct(Func<BE.Contract, bool> predicate = null)
        {
            IEnumerable<Contract> num_contract = get_Contracts(predicate);
            int count = 0;
            foreach (Contract item in num_contract)
                count++;
            return count;
        }

        /// <summary>
        /// retruns the spicalization from a contract(in the cint their is a number)
        /// </summary>
        /// <param name="c"></param>
        /// <returns></returns>
        public Specialization speciality_type (Contract c)
        {
            Employee e = get_employee(c.Employee_id);
            Specialization s = get_specialization(e.Speciality_number);
            return s;
        }

        #region grouping functions
        /// <summary>
        /// groups the contracts by spiciality type
        /// </summary>
        /// <param name="sort"></param>
        /// <returns></returns>
        public IEnumerable<IGrouping<string, BE.Contract>> spcialization_contracts(bool sort = false)
        {
            IEnumerable<IGrouping<string, BE.Contract>> contract_group;
           
            if (sort == true)
            {
                contract_group = from c in get_Contracts().ToList()
                                     orderby c.Contract_number
                                     group c by speciality_type(c).Speciality_name;
            }
            else
            {
                 contract_group = from c in get_Contracts().ToList()
                                  group c by speciality_type(c).Speciality_name;
            }
            return contract_group;


        }
       
        /// <summary>
        /// groups the cont by employer
        /// </summary>
        /// <param name="sort"></param>
        /// <returns></returns>
        public IEnumerable<IGrouping<string, BE.Contract>> city_contracts(bool sort = false)
        {
            IEnumerable<IGrouping<string, BE.Contract>> contract_group;
            if (sort == true)
            {
                contract_group = from c in get_Contracts().ToList()
                                 orderby c.Contract_number
                                 group c by get_employer(c.Employer_id).Address;
            }
            else
            {
                contract_group = from c in get_Contracts().ToList()
                                 group c by get_employer(c.Employer_id).Address;
            }
            return contract_group;


        }

        //returns the  new profit for every year (not encluding the last years)
        public IEnumerable profit_per_year()
        {
            var v = from item in get_Contracts().ToList()
                    orderby item.Beginning_of_work.Year
                    group item by item.Beginning_of_work.Year into g
                    select new { year = g.Key, profit = g.Sum(item => (item.Rate_per_hour_gross - item.Rate_per_hour_net) * item.Num_hours_of_work * (12 - item.Beginning_of_work.Month)) };
            return v;
        }

        /// <summary>
        /// returns the employees groupd by their specialization if orderd-by their experiance
        /// </summary>
        public IEnumerable<IGrouping<string, Employee>> spcialization_employees(bool sort = false)
        {
            IEnumerable<IGrouping<string, BE.Employee>> employee_group;
            if (sort == true)
            {
                employee_group = from e in get_employees().ToList()
                                 orderby e.Experiance
                                 group e by e.Speciality_number;
            }
            else
            {
                employee_group = from e in get_employees().ToList()
                                 group e by e.Speciality_number;
            }
            return employee_group;


        }

        /// <summary>
        /// returns the employees groups by their accadimic degree, if sorted by their specializiation
        /// </summary>
        public IEnumerable<IGrouping<BE.enumClass.academic_state, BE.Employee>> degree_employees(bool sort = false)
        {
            IEnumerable<IGrouping<BE.enumClass.academic_state, BE.Employee>> employee_group;
            if (sort == true)
            {
                employee_group = from e in get_employees().ToList()
                                 orderby e.Speciality_number
                                 group e by e.Accademic_degree;
            }
            else
            {
                employee_group = from e in get_employees().ToList()
                                 group e by e.Accademic_degree;
            }
            return employee_group;
        }

        /// <summary>
        /// returns the employees groups by army state, if sorted by their id
        /// </summary> 
        public IEnumerable<IGrouping<bool, Employee>> Army_graduate(bool sort = false)
        {
            IEnumerable<IGrouping<bool, BE.Employee>> employee_group;
            if (sort == true)
            {
                employee_group = from e in get_employees().ToList()
                                 orderby e.Id_number
                                 group e by e.Army_graduate;
            }
            else
            {
                employee_group = from e in get_employees().ToList()
                                 group e by e.Army_graduate;
            }
            return employee_group;
        }

        /// <summary>
        /// returns the employers groupd by private or not, if sorted by their id
        /// </summary>
        public IEnumerable<IGrouping<bool, Employer>> privet_employers(bool sort = false)
        {
            IEnumerable<IGrouping<bool, BE.Employer>> employer_group;
            if (sort == true)
            {
                employer_group = from e in get_employers().ToList()
                                 orderby e.Id_number
                                 group e by e.IsPrivate;
            }
            else
            {
                employer_group = from e in get_employers().ToList()
                                 group e by e.IsPrivate;
            }
            return employer_group;
        }

        /// <summary>
        /// returns the specializations ordered by minimum rate in in- ordersd by max,
        /// </summary>
        public IOrderedEnumerable<Specialization> spcialization_ordered()
        {
            var specialization_group = from s in get_specializiations().ToList()
                                       orderby s.MinRatePerHour,s.MaxRatePerHour
                                       select s;
            return specialization_group;
        }

        /// <summary>
        /// returns all emplyees for a employer
        /// </summary>
        public IEnumerable<Employee> employees_to_employer(string employer_id)
        {
            IEnumerable<Contract> list = get_Contracts(c => c.Employer_id == employer_id);
            var employees = from item in list
                            select get_employee(item.Employee_id);
            return employees; 
        }
        #endregion

        //calculates the gross salery per hour
        public double calculate_grooss_hourly_salery(string employee_id)
        {
            Employee emp = get_employee(employee_id);
            var specialy = get_specializiations(e => e.Speciality_number == emp.Speciality_number);
            double max=0;
            double min=0;
            foreach (var item in specialy)
            {
                 max = item.MaxRatePerHour;
                 min = item.MinRatePerHour;
            }
            double gross_rate = min + (max * emp.Experiance / 100);
            if (emp.Accademic_degree == enumClass.academic_state.BA)
                gross_rate += max * 0.05;
            if (emp.Accademic_degree == enumClass.academic_state.MA)
                gross_rate += max * 0.10;
            if (emp.Accademic_degree == enumClass.academic_state.PHD)
                gross_rate += max * 0.15;

            return gross_rate;
        }
    }
}
