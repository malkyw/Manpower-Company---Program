﻿using BE;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static BE.enumClass;
using System.Web;
using System.ComponentModel;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Net.NetworkInformation;
using System.Xml.Serialization;

namespace DAL
{
    class Dal_XML_imp : IDAL
    {

        XElement specialization_root;
        string specialization_path = @"SpecializationXml.xml";

        XElement employer_root;
        string employer_path = @"EmployerXml.xml";

        XElement employee_root;
        string employee_path = @"EmployeeXml.xml";

        XElement contract_root;
        string contract_path = @"ContractXml.xml";

        XElement config_root;
        string config_path = @"config.xml";

          const string xmlLocalPath = @"atm.xml";
           static bool downloadFinished = false;


        public Dal_XML_imp()
        {

            Thread t = new Thread(DownloadXml);
            t.Start();

            if (!File.Exists(specialization_path))
                CreateFiles(specialization_root, specialization_path);
            else
                Load_specialization_data();

            if (!File.Exists(employer_path))
                CreateFiles(employer_root, employer_path);
            else
                Load_employer_data();

            if (!File.Exists(employee_path))
                CreateFiles(employee_root, employee_path);
            else
                Load_employee_data();

            if (!File.Exists(contract_path))
                CreateFiles(contract_root, contract_path);
            else
                Load_contract_data();

            if (!File.Exists(config_path))
                CreateFiles(config_root, config_path);
            else
                Load_config_data();
        }
    
        private static void DownloadXml()
        {
           
            WebClient wc = new WebClient();
            try
            {
                string xmlServerPath =
               @"http://www.boi.org.il/he/BankingSupervision/BanksAndBranchLocations/Lists/BoiBankBranchesDocs/atm.xml";
                wc.DownloadFile(xmlServerPath, xmlLocalPath);
                downloadFinished = true;

            }
            catch (Exception)
            {
                string xmlServerPath = @"http://www.jct.ac.il/~coshri/atm.xml";
                wc.DownloadFile(xmlServerPath, xmlLocalPath);
                downloadFinished = true;

            }
            finally
            {
                wc.Dispose();
            }
        }

        private void CreateFiles( XElement x, string s)
        {
            if (s == specialization_path )
            {
                specialization_root = new XElement("specialization");
                specialization_root.Save(specialization_path);
            }
            if (s == employer_path)
            {
                employer_root = new XElement("employer");
                employer_root.Save(employer_path);
            }
            if (s == employee_path)
            {
                employee_root = new XElement("employee");
                employee_root.Save(employee_path);
            }
            if (s == contract_path)
            {
                contract_root = new XElement("contract");
                contract_root.Save(contract_path);
            }
                if (s == config_path)
            {
                config_root = new XElement("stat_num");
                XElement spec_number = new XElement("specialization", 10000000);
                XElement cont_number = new XElement("contract", 10000000);
                XElement stat_num = new XElement("stat_num", spec_number, cont_number);
                config_root.Add(stat_num);
                config_root.Save(config_path);
            }           
        }

        #region load functions
        private void Load_specialization_data()
        {
            try
            {
                specialization_root = XElement.Load(specialization_path);
            }
            catch
            {
                throw new Exception("File upload problem");
            }
        }

        private void Load_employer_data()
        {
            try
            {
                employer_root = XElement.Load(employer_path);
            }
            catch
            {
                throw new Exception("File upload problem");
            }
        }

        private void Load_employee_data()
        {
            try
            {
                employee_root = XElement.Load(employee_path);
            }
            catch
            {
                throw new Exception("File upload problem");
            }
        }

        private void Load_contract_data()
        {
            try
            {
                contract_root = XElement.Load(contract_path);
            }
            catch
            {
                throw new Exception("File upload problem");
            }
        }

        private void Load_config_data()
        {
            try
            {
                config_root = XElement.Load(config_path);
            }
            catch
            {
                throw new Exception("File upload problem");
            }
        }

        //private void load_bank_data()
        //{
        //    try
        //    {
        //        bank_root = XElement.Load(xmlLocalPath);
        //    }
        //    catch
        //    {
        //        throw new Exception("File upload problem");

       
        #endregion

        #region specialization functions

        public IEnumerable<Specialization> get_specializiations(Func<Specialization, bool> predicate = null)
        {
            Load_specialization_data();
            List<Specialization> specializations;
            try
            {
                specializations = (from p in specialization_root.Elements()
                                   select new Specialization()
                                   {
                                       Speciality_number = (p.Element("speciality_number").Value),
                                       Speciality_name = (p.Element("speciality_name").Value),
                                       SpecialityField = (specializatinFailed)Enum.Parse(typeof(specializatinFailed), p.Element("specialityField").Value),
                                       MinRatePerHour = Convert.ToInt32(p.Element("ratePerHour").Element("minRatePerHour").Value),
                                       MaxRatePerHour = Convert.ToInt32(p.Element("ratePerHour").Element("maxRatePerHour").Value)
                                   }).ToList();
            }
            catch
            {
                specializations = null;
            }
           if (predicate != null)
                return specializations.Where(predicate);
            return specializations;
        }

        public Specialization get_specialization(string id)
        {
            Load_specialization_data();
            Specialization specialization;
            try
            {
                specialization = (from p in specialization_root.Elements()
                                  where (p.Element("speciality_number").Value) == id
                                  select new Specialization()
                                  {
                                      Speciality_number = (p.Element("speciality_number").Value),
                                      Speciality_name = (p.Element("speciality_name").Value),
                                      SpecialityField = (specializatinFailed)Enum.Parse(typeof(specializatinFailed), p.Element("specialityField").Value),
                                      MinRatePerHour = Convert.ToInt32(p.Element("ratePerHour").Element("minRatePerHour").Value),
                                      MaxRatePerHour = Convert.ToInt32(p.Element("ratePerHour").Element("maxRatePerHour").Value)
                                  }).FirstOrDefault();
            }
            catch
            {
                specialization = null;
            }
            return specialization;
        }

        public void add_specialization(Specialization specialization)
        {
            XElement Speciality_number = new XElement("speciality_number", specialization.Speciality_number);
            XElement Speciality_name = new XElement("speciality_name", specialization.Speciality_name);
            XElement SpecialityField = new XElement("specialityField", specialization.SpecialityField);
            XElement MinRatePerHour = new XElement("minRatePerHour", specialization.MinRatePerHour);
            XElement MaxRatePerHour = new XElement("maxRatePerHour", specialization.MaxRatePerHour);
            XElement ratePerHour = new XElement("ratePerHour", MinRatePerHour, MaxRatePerHour);
            specialization_root.Add(new XElement("specialization", Speciality_number, Speciality_name, SpecialityField, ratePerHour));
            specialization_root.Save(specialization_path);
        }

        public void delete_specializiation(string id)
        {
            XElement specializiationElement;
            try
            {
                specializiationElement = (from p in specialization_root.Elements()
                                          where (p.Element("speciality_number").Value) == id
                                          select p).FirstOrDefault();
                if (specializiationElement == null)
                    throw new Exception("a Specialization with this number does not exists.\n");
                if (get_employees(e => e.Speciality_number == id).Any())
                    throw new Exception("the Specialization is used by some employees!!!\n");
                specializiationElement.Remove();
                specialization_root.Save(specialization_path);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void update_specializiation(Specialization specialization)
        {
            XElement specializationElement = (from p in specialization_root.Elements()
                                              where (p.Element("speciality_number").Value) == specialization.Speciality_number
                                              select p).FirstOrDefault();
            if (specializationElement == null)
                throw new Exception("specialization with this number not found.\n");
            specializationElement.Element("speciality_name").Value = specialization.Speciality_name;
            specializationElement.Element("specialityField").Value = Enum.GetName((specialization.SpecialityField).GetType(), specialization.SpecialityField);
            specializationElement.Element("ratePerHour").Element("minRatePerHour").Value = Convert.ToString(specialization.MinRatePerHour);
            specializationElement.Element("ratePerHour").Element("maxRatePerHour").Value = Convert.ToString(specialization.MaxRatePerHour);

            specializationElement.Save(specialization_path);
            specialization_root.Save(specialization_path);
        }

        public void give_spiciality_number(Specialization spec)
        {

            int num = int.Parse(config_root.Element("stat_num").Element("specialization").Value);
            num++;
            config_root.Element("stat_num").Element("specialization").Value = Convert.ToString(num);
            config_root.Save(config_path);
            spec.Speciality_number = Convert.ToString(num);

        }
        #endregion

        #region employer functions
    /// <summary>
    /// returns all employers
    /// </summary>
    /// <param name="predicate"></param>
    /// <returns></returns>
        public IEnumerable<Employer> get_employers(Func<Employer, bool> predicate = null)
        {
            Load_employer_data();
            List<Employer> employers;
            try
            {
                employers = (from p in employer_root.Elements()
                                   select new Employer()
                                   {
                                       Id_number = p.Element("id_number").Value,
                                       First_name =p.Element("name").Element("first_name").Value,
                                       Last_name = p.Element("name").Element("last_name").Value,
                                       IsPrivate = Convert.ToBoolean(p.Element("isPrivate").Value),
                                       CompanyName = p.Element("companyName").Value,
                                       Phone_number = p.Element("phone_number").Value,
                                       Address = p.Element("address").Value,
                                       ImageSource = p.Element("imageSource").Value,
                                       OccupationField = (specializatinFailed)Enum.Parse(typeof(specializatinFailed), p.Element("occupationField").Value),
                                       BusinessCreationDate = Convert.ToDateTime(p.Element("businessCreationDate").Value),
                                   }).ToList();
            }
            catch
            {
                employers = null;
            }
            if (predicate != null)
                return employers.Where(predicate);
            return employers;
        }

        /// <summary>
        /// returns one employer
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Employer get_employer(string id)
        {
            Load_employer_data();
            Employer employer;
            try
            {
                employer = (from p in employer_root.Elements()
                                  where (p.Element("id_number").Value) == id
                                  select new Employer()
                                  {
                                      Id_number = p.Element("id_number").Value,
                                      First_name = p.Element("name").Element("first_name").Value,
                                      Last_name = p.Element("name").Element("last_name").Value,
                                      IsPrivate = Convert.ToBoolean(p.Element("isPrivate").Value),
                                      CompanyName = p.Element("companyName").Value,
                                      Phone_number = p.Element("phone_number").Value,
                                      Address = p.Element("address").Value,
                                      ImageSource = p.Element("imageSource").Value,
                                      OccupationField = (specializatinFailed)Enum.Parse(typeof(specializatinFailed), p.Element("occupationField").Value),
                                      BusinessCreationDate = Convert.ToDateTime(p.Element("businessCreationDate").Value),
                                  }).FirstOrDefault();
            }
            catch
            {
                employer = null;
            }
            return employer;
        }

        /// <summary>
        /// add employer
        /// </summary>
        /// <param name="employer"></param>
        public void add_employer(Employer employer)
        {
            Employer temp = get_employer(employer.Id_number);
            if (temp != null)
                throw new Exception("an employer with the same ID number already exists.\n");
            XElement Id_number = new XElement("id_number", employer.Id_number);
            XElement First_name = new XElement("first_name", employer.First_name);
            XElement Last_name = new XElement("last_name", employer.Last_name);
            XElement Name = new XElement("name", First_name, Last_name);
            XElement IsPrivate = new XElement("isPrivate", employer.IsPrivate);
            XElement CompanyName = new XElement("companyName", employer.CompanyName);
            XElement Phone_number = new XElement("phone_number", employer.Phone_number);
            XElement Address = new XElement("address", employer.Address);
            XElement ImageSource = new XElement("imageSource", employer.ImageSource);
            XElement OccupationField = new XElement("occupationField", employer.OccupationField);
            XElement BusinessCreationDate = new XElement("businessCreationDate", employer.BusinessCreationDate);

            employer_root.Add(new XElement("employer", Id_number, Name, IsPrivate, CompanyName, Phone_number, Address, ImageSource, OccupationField, BusinessCreationDate));
            employer_root.Save(employer_path);
        }

        /// <summary>
        /// delete employer
        /// </summary>
        /// <param name="id"></param>
        public void delete_employer(string id)
        {
            XElement employerElement;
            try
            {
                employerElement = (from p in employer_root.Elements()
                                          where (p.Element("id_number").Value) == id
                                          select p).FirstOrDefault();
                if (employerElement == null)
                    throw new Exception("an employer with this id number does not exists.\n");
                IEnumerable<Contract> contracts = get_Contracts(c => c.Employer_id == id);
                foreach (Contract item in contracts)
                    delete_contract(item.Contract_number);
                employerElement.Remove();
                employer_root.Save(employer_path);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// update employer
        /// </summary>
        /// <param name="employer"></param>
        public void update_employer(Employer employer)
        {
            XElement employerElement = (from p in employer_root.Elements()
                                              where (p.Element("id_number").Value) == employer.Id_number
                                              select p).FirstOrDefault();
            if (employerElement == null)
                throw new Exception("an employer with this id number is not found.\n");
            employerElement.Element("name").Element("first_name").Value =employer.First_name;
            employerElement.Element("name").Element("last_name").Value = employer.Last_name;
            employerElement.Element("isPrivate").Value =Convert.ToString( employer.IsPrivate);
            employerElement.Element("companyName").Value = employer.CompanyName;
            employerElement.Element("phone_number").Value = employer.Phone_number;
            employerElement.Element("address").Value = employer.Address;
            employerElement.Element("imageSource").Value = employer.ImageSource;
            employerElement.Element("occupationField").Value = Enum.GetName((employer.OccupationField).GetType(), employer.OccupationField);
            employerElement.Element("businessCreationDate").Value = Convert.ToString(employer.BusinessCreationDate);

            employerElement.Save(employer_path);
            employer_root.Save(employer_path);
        }
        #endregion

        #region employee functions

        /// <summary>
/// returns all employees
/// </summary>
/// <param name="predicate"></param>
/// <returns></returns>
        public IEnumerable<Employee> get_employees(Func<Employee, bool> predicate = null)
        {
            Load_employee_data();
            List<Employee> employees;
            try
            {
                employees = (from p in employee_root.Elements()
                             select new Employee()
                             {
                                 Id_number = p.Element("id_number").Value,
                                 First_name = p.Element("name").Element("first_name").Value,
                                 Last_name = p.Element("name").Element("last_name").Value,
                                 Phone_number = p.Element("phone_number").Value,
                                 Address = p.Element("address").Value,
                                 Experiance = Convert.ToInt32(p.Element("experiance").Value),
                                 Speciality_number = p.Element("speciality_number").Value,
                                 Recommemdations = p.Element("recommemdations").Value,
                                 ImageSource = p.Element("imageSource").Value,
                                 Army_graduate = Convert.ToBoolean(p.Element("army_graduate").Value),
                                 Accademic_degree = (academic_state)Enum.Parse(typeof(academic_state), p.Element("accademic_degree").Value),
                                 Birth_date = Convert.ToDateTime(p.Element("birth_date").Value),
                                 Bank_information = new BankAccount()
                                 {
                                     AccountNumber = Convert.ToInt32(p.Element("bank_information").Element("accountNumber").Value),
                                     BankNumber = Convert.ToInt32(p.Element("bank_information").Element("bank").Element("bankNumber").Value),
                                     BankName = p.Element("bank_information").Element("bank").Element("bankName").Value,
                                     BankBranchNumber = Convert.ToInt32(p.Element("bank_information").Element("branch").Element("bankBranchNumber").Value),
                                     BranchAddress = p.Element("bank_information").Element("branch").Element("branchAddress").Value,
                                     BranchCity = p.Element("bank_information").Element("branch").Element("branchCity").Value
                                 },

                             }).ToList();
            }
            catch
            {
                employees = null;
            }
            if (predicate != null)
                return employees.Where(predicate);
            return employees;
        }

        /// <summary>
        /// returns one employee
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Employee get_employee(string id)
        {
            Load_employee_data();
            Employee employee;
            try
            {
                employee = (from p in employee_root.Elements()
                            where (p.Element("id_number").Value) == id
                            select new Employee()
                            {
                                Id_number = p.Element("id_number").Value,
                                First_name = p.Element("name").Element("first_name").Value,
                                Last_name = p.Element("name").Element("last_name").Value,
                                Phone_number = p.Element("phone_number").Value,
                                Address = p.Element("address").Value,
                                Experiance = Convert.ToInt32(p.Element("experiance").Value),
                                Speciality_number = p.Element("speciality_number").Value,
                                Recommemdations = p.Element("recommemdations").Value,
                                ImageSource = p.Element("imageSource").Value,
                                Army_graduate = Convert.ToBoolean(p.Element("army_graduate").Value),
                                Accademic_degree = (academic_state)Enum.Parse(typeof(academic_state), p.Element("accademic_degree").Value),
                                Birth_date = Convert.ToDateTime(p.Element("birth_date").Value),
                                Bank_information = new BankAccount()
                                {
                                    AccountNumber = Convert.ToInt32(p.Element("bank_information").Element("accountNumber").Value),
                                    BankNumber = Convert.ToInt32(p.Element("bank_information").Element("bank").Element("bankNumber").Value),
                                    BankName = p.Element("bank_information").Element("bank").Element("bankName").Value,
                                    BankBranchNumber = Convert.ToInt32(p.Element("bank_information").Element("branch").Element("bankBranchNumber").Value),
                                    BranchAddress = p.Element("bank_information").Element("branch").Element("branchAddress").Value,
                                    BranchCity = p.Element("bank_information").Element("branch").Element("branchCity").Value
                                },
                            }).FirstOrDefault();
            }
            catch
            {
                employee = null;
            }
            return employee;
        }


        /// <summary>
        /// add employee
        /// </summary>
        /// <param name="employee"></param>
        public void add_employee(Employee employee)
        {
            Employee temp = get_employee(employee.Id_number);
            if (temp != null)
                throw new Exception("an employee with the same ID number already exists.\n");
            XElement Id_number = new XElement("id_number", employee.Id_number);
            XElement First_name = new XElement("first_name", employee.First_name);
            XElement Last_name = new XElement("last_name", employee.Last_name);
            XElement Name = new XElement("name", First_name, Last_name);
            XElement Phone_number = new XElement("phone_number", employee.Phone_number);
            XElement Address = new XElement("address", employee.Address);
            XElement ImageSource = new XElement("imageSource", employee.ImageSource);
            XElement Experiance = new XElement("experiance", employee.Experiance);
            XElement Speciality_number = new XElement("speciality_number", employee.Speciality_number);
            XElement Recommemdations = new XElement("recommemdations", employee.Recommemdations);
            XElement Army_graduate = new XElement("army_graduate", employee.Army_graduate);
            XElement Accademic_degree = new XElement("accademic_degree", employee.Accademic_degree);
            XElement Birth_date = new XElement("birth_date", employee.Birth_date);
            XElement AccountNumber = new XElement("accountNumber", employee.Bank_information.AccountNumber);
            XElement BankNumber = new XElement("bankNumber", employee.Bank_information.BankNumber);
            XElement BankName = new XElement("bankName", employee.Bank_information.BankName);
            XElement Bank = new XElement("bank", BankNumber, BankName);
            XElement BankBranchNumber = new XElement("bankBranchNumber", employee.Bank_information.BankBranchNumber);
            XElement BranchAddress = new XElement("branchAddress", employee.Bank_information.BranchAddress);
            XElement BranchCity = new XElement("branchCity", employee.Bank_information.BranchCity);
            XElement Branch = new XElement("branch", BankBranchNumber, BranchAddress, BranchCity);
            XElement Bank_information = new XElement("bank_information", AccountNumber, Bank, Branch);
            employee_root.Add(new XElement("employee", Id_number, Name, Phone_number, Address, ImageSource, Experiance, Speciality_number, Recommemdations, Army_graduate, Accademic_degree, Birth_date,Bank_information));
            employee_root.Save(employee_path);
        }

        /// <summary>
        /// delete employee
        /// </summary>
        /// <param name="id"></param>
        public void delete_employee(string id)
        {
            XElement employeeElement;
            try
            {
                employeeElement = (from p in employee_root.Elements()
                                   where (p.Element("id_number").Value) == id
                                   select p).FirstOrDefault();
                if (employeeElement == null)
                    throw new Exception("an employee with this id number does not exists.\n");
                IEnumerable<Contract> contracts = get_Contracts(c => c.Employee_id == id);
                foreach (Contract item in contracts)
                    delete_contract(item.Contract_number);
                employeeElement.Remove();
                employee_root.Save(employee_path);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// update employee
        /// </summary>
        /// <param name="employee"></param>
        public void update_employee(Employee employee)
        {
            XElement employeeElement = (from p in employee_root.Elements()
                                        where (p.Element("id_number").Value) == employee.Id_number
                                        select p).FirstOrDefault();
            if (employeeElement == null)
                throw new Exception("an employee with this id number is not found.\n");
            employeeElement.Element("name").Element("first_name").Value = employee.First_name;
            employeeElement.Element("name").Element("last_name").Value = employee.Last_name;
            employeeElement.Element("phone_number").Value = employee.Phone_number;
            employeeElement.Element("address").Value = employee.Address;
            employeeElement.Element("imageSource").Value = employee.ImageSource;
            employeeElement.Element("army_graduate").Value = Convert.ToString(employee.Army_graduate);
            employeeElement.Element("experiance").Value =Convert.ToString(employee.Experiance);
            employeeElement.Element("speciality_number").Value = Convert.ToString(employee.Speciality_number);
            employeeElement.Element("recommemdations").Value = employee.Recommemdations;
            employeeElement.Element("accademic_degree").Value = Enum.GetName((employee.Accademic_degree).GetType(), employee.Accademic_degree);
            employeeElement.Element("birth_date").Value = Convert.ToString(employee.Birth_date);
            employeeElement.Element("bank_information").Element("accountNumber").Value = Convert.ToString(employee.Bank_information.AccountNumber);
            employeeElement.Element("bank_information").Element("bank").Element("bankNumber").Value = Convert.ToString(employee.Bank_information.BankNumber);
            employeeElement.Element("bank_information").Element("bank").Element("bankName").Value = employee.Bank_information.BankName;
            employeeElement.Element("bank_information").Element("branch").Element("bankBranchNumber").Value = Convert.ToString(employee.Bank_information.BankBranchNumber);
            employeeElement.Element("bank_information").Element("branch").Element("branchAddress").Value = employee.Bank_information.BranchAddress;
            employeeElement.Element("bank_information").Element("branch").Element("branchCity").Value = employee.Bank_information.BranchCity;

            employeeElement.Save(employee_path);
            employee_root.Save(employee_path);
        }
        #endregion

        #region contract functions
        /// <summary>
        /// add contract
        /// </summary>
        /// <param name="contract"></param>
        public void add_contract(Contract contract)
        {
            XElement Contract_number = new XElement("contract_number", contract.Contract_number);
            XElement Employer_id = new XElement("employer_id", contract.Employer_id);
            XElement Employee_id = new XElement("employee_id", contract.Employee_id);
            XElement Had_interviewed = new XElement("had_interviewed", contract.Had_interviewed);
            XElement Had_sighed_contract = new XElement("had_sighed_contract", contract.Had_sighed_contract);
            XElement Rate_per_hour_gross = new XElement("rate_per_hour_gross", contract.Rate_per_hour_gross);
            XElement Rate_per_hour_net = new XElement("rate_per_hour_net", contract.Rate_per_hour_net);
            XElement Beginning_of_work = new XElement("beginning_of_work", contract.Beginning_of_work);
            XElement End_of_work = new XElement("end_of_work", contract.End_of_work);
            XElement Num_hours_of_work = new XElement("num_hours_of_work", contract.Num_hours_of_work);
            contract_root.Add(new XElement("contract", Contract_number, Employer_id, Employee_id, Had_interviewed, Had_sighed_contract, Rate_per_hour_gross, Rate_per_hour_net, Beginning_of_work, End_of_work, Num_hours_of_work));
            contract_root.Save(contract_path);
        }

        /// <summary>
        /// delete contract
        /// </summary>
        /// <param name="id"></param>
        public void delete_contract(string id)
        {
            XElement contractElement;
            try
            {
                contractElement = (from p in contract_root.Elements()
                                   where (p.Element("contract_number").Value) == id
                                   select p).FirstOrDefault();
                if (contractElement == null)
                    throw new Exception("a contract with this number does not exists.\n");
                
                contractElement.Remove();
                contract_root.Save(contract_path);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// update contract
        /// </summary>
        /// <param name="contract"></param>
        public void update_Contract(Contract contract)
        {
            XElement contractElement = (from p in contract_root.Elements()
                                        where (p.Element("contract_number").Value) == contract.Contract_number
                                        select p).FirstOrDefault();
            if (contractElement == null)
                throw new Exception("contract with this number not found.\n");
            contractElement.Element("employer_id").Value = contract.Employer_id;
            contractElement.Element("employee_id").Value = contract.Employee_id;
            contractElement.Element("had_interviewed").Value = Convert.ToString(contract.Had_interviewed);
            contractElement.Element("had_sighed_contract").Value = Convert.ToString(contract.Had_sighed_contract);
            contractElement.Element("rate_per_hour_gross").Value = Convert.ToString(contract.Rate_per_hour_gross);
            contractElement.Element("rate_per_hour_net").Value = Convert.ToString(contract.Rate_per_hour_net);
            contractElement.Element("beginning_of_work").Value = Convert.ToString(contract.Beginning_of_work);
            contractElement.Element("end_of_work").Value = Convert.ToString(contract.End_of_work);
            contractElement.Element("num_hours_of_work").Value = Convert.ToString(contract.Num_hours_of_work);


            contractElement.Save(contract_path);
            contract_root.Save(contract_path);
        }

        /// <summary>
        /// returns one contract
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Contract get_contract(string id)
        {
            Load_contract_data();
            Contract contract;
            try
            {
                contract = (from p in contract_root.Elements()
                            where (p.Element("contract_number").Value) == id
                            select new Contract()
                            {
                                Contract_number = (p.Element("contract_number").Value),
                                Employer_id = (p.Element("employer_id").Value),
                                Employee_id = (p.Element("employee_id").Value),
                                Had_interviewed = Convert.ToBoolean(p.Element("had_interviewed").Value),
                                Had_sighed_contract = Convert.ToBoolean(p.Element("had_sighed_contract").Value),
                                Rate_per_hour_gross = Convert.ToDouble(p.Element("rate_per_hour_gross").Value),
                                Rate_per_hour_net = Convert.ToDouble(p.Element("rate_per_hour_net").Value),
                                Beginning_of_work = Convert.ToDateTime(p.Element("beginning_of_work").Value),
                                End_of_work = Convert.ToDateTime(p.Element("end_of_work").Value),
                                Num_hours_of_work = Convert.ToInt32(p.Element("num_hours_of_work").Value)
                            }).FirstOrDefault();
            }
            catch
            {
                contract = null;
            }
            return contract;
        }

        /// <summary>
        /// returns all contract
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public IEnumerable<Contract> get_Contracts(Func<Contract, bool> predicate = null)
        {
            Load_contract_data();
            List<Contract> contracts;
            try
            {
                contracts = (from p in contract_root.Elements()
                             select new Contract()
                             {
                                 Contract_number = (p.Element("contract_number").Value),
                                 Employer_id = (p.Element("employer_id").Value),
                                 Employee_id = (p.Element("employee_id").Value),
                                 Had_interviewed = Convert.ToBoolean(p.Element("had_interviewed").Value),
                                 Had_sighed_contract = Convert.ToBoolean(p.Element("had_sighed_contract").Value),
                                 Rate_per_hour_gross = Convert.ToDouble(p.Element("rate_per_hour_gross").Value),
                                 Rate_per_hour_net = Convert.ToDouble(p.Element("rate_per_hour_net").Value),
                                 Beginning_of_work = Convert.ToDateTime(p.Element("beginning_of_work").Value),
                                 End_of_work = Convert.ToDateTime(p.Element("end_of_work").Value),
                                 Num_hours_of_work =Convert.ToInt32( p.Element("num_hours_of_work").Value)
                             }).ToList();
            }
            catch
            {
                contracts = null;
            }
            if (predicate != null)
                return contracts.Where(predicate);
            return contracts;
        }

        /// <summary>
        /// give number to contract
        /// </summary>
        /// <param name="cont"></param>
        public void give_contract_number(Contract cont)
        {

            int num = int.Parse(config_root.Element("stat_num").Element("contract").Value);
            num++;
            config_root.Element("stat_num").Element("contract").Value = Convert.ToString(num);
            config_root.Save(config_path);
            cont.Contract_number = Convert.ToString(num);

        }
        #endregion

        #region bank functions
        /// <summary>
        /// returns all atm 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<BankAccount> GetAllAtm()
        {
            if (downloadFinished == false)
                throw new Exception("download is not finisheed already");

            XElement xml = XElement.Load(xmlLocalPath);

            var allAtm = from item in xml.Elements()
                    select new BankAccount
                    {
                    BankNumber = int.Parse(item.Element("קוד_בנק").Value),
                    BankBranchNumber = int.Parse(item.Element("קוד_סניף").Value),
                    BankName = item.Element("שם_בנק").Value.Replace('\n', ' ').Trim(),
                    BranchAddress = item.Element("כתובת_ה-ATM").Value.Replace('\n', ' ').Trim(),
                    BranchCity = item.Element("ישוב").Value.Replace('\n', ' ').Trim(),
                    };
            return allAtm;
            }

        /// <summary>
        /// returns all atm grouped by banks
        /// </summary>
        /// <returns></returns>
        public IEnumerable<IGrouping<string,BankAccount>> GetAllAtmGroupByBank()
        {
            return from atm in GetAllAtm()
                   group atm by atm.BankName;
        }

        /// <summary>
        /// returns all bank names
        /// </summary>
        /// <returns></returns>
        public IEnumerable<string> GetAllBankNames()
        {
            return (from atm in GetAllAtm()
                    select atm.BankName).Distinct();

        }

        /// <summary>
        /// returns all bank branches
        /// </summary>
        /// <param name="bankName"></param>
        /// <returns></returns>
        public IEnumerable<BankAccount> GetAllBankbranches(string bankName)
        {
            return (from atm in GetAllAtm()
                    where atm.BankName.CompareTo(bankName) == 0
                    select atm).Distinct();
        }
        #endregion
    }
}

